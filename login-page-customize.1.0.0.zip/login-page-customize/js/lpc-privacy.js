;(function($){
    'use strict';

    jQuery(document).ready(function(){
        /* ==================================
         Privacy Policy Link New Tab Open
        ================================== */
        jQuery('body.login #login .privacy-policy-page-link a').attr('target', '_blank');
    
    });

}(jQuery));