;(function($){
    'use strict';

    jQuery(document).ready(function(){
        /* ======================
         Logo Link New Tab Open
        ====================== */
        jQuery('body.login #login h1 a').attr('target', '_blank');
    
    });

}(jQuery));