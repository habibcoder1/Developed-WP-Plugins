<?php  
// Silence is golden