(function($){
	jQuery(document).ready(function(){
		'use strict';

		// Right click disabled script
		jQuery(function(){
			jQuery(this).bind('contextmenu', function(event){
				event.preventDefault();
			});
		});

	});
})(jQuery);