<?php 

/* ===================================
Plugin Name: Right Click Disable for Secure
Plugin URI: http://websiteslearn.com
Author: HR Habib
Author URI: http://habibcoder.com
Version: 1.0.0
Requires at least: 5.5
Tested up to: 6.0
Requires PHP: 7.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Description: Right Click Disable for Secure is WP Website Secure Plugin. If we want more security for our website then we can use this plugin.
Tags: right click disable for secure, right click disable, hr right click disable, wp secure, wp website secure 
Text Domain: hrrightcd

==================================== */


// ABSPATH
if (! defined('ABSPATH')) {
	exit();
}



// Script Enqueue
add_action('wp_enqueue_scripts', 'hr_right_click_disable_secure');
function hr_right_click_disable_secure(){

	wp_enqueue_script('hr-rcd-custom', PLUGINS_URL('js/custom.js', __FILE__), array('jquery'), '1.0.0', false);

}