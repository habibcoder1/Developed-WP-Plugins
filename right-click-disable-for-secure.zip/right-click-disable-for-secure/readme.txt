=== Right Click Disable for Secure ===
Contributors: hrhabibpro
Donate link: https:websiteslearn.com
Tags: right click disable for secure, right click disable, hr right click disable, wp secure, wp website secure
Requires at least: 5.5
Tested up to: 6.0
Stable tag: 1.0.0
Requires PHP: 7.0
License: GNU General Public License v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Right Click Disable for Secure is WP Website Secure Plugin. If we want more security for our website then we can use this plugin.

== Description ==

Right Click Disable for Secure is WordPress Website Secure Plugin. If you want more secure our website then we can use this plugin.



== Frequently Asked Questions ==

= Really, Is it give more secure for my website? =

Yes, Your website will be more secure.

= MayI use right-click functionality after activating this plugin? =

No, your right click will diable.

= Is it user-friendly? =

Yes, it is a user-friendly plugin.

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Screenshots are stored in the /assets directory.
2. This is the second screen shot

== Changelog ==

= 1.0.0 =
* A new version


== Upgrade Notice ==

= 1.0 =
Upgrade notices describe the reason a user should upgrade.  No more than 300 characters.


== A brief Markdown Example ==

Markdown is what the parser uses to process much of the readme file.

[markdown syntax]: https://daringfireball.net/projects/markdown/syntax

Ordered list:

1. Some feature
1. Another feature
1. Something else about the plugin

Unordered list:

* something
* something else
* third thing

Links require brackets and parenthesis:

Here's a link to [WordPress](https://wordpress.org/ "Your favorite software") and one to [Markdown's Syntax Documentation][markdown syntax]. Link titles are optional, naturally.

Blockquotes are email style:

> Asterisks for *emphasis*. Double it up  for **strong**.

And Backticks for code:

`<?php code(); ?>`