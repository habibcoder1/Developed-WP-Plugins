<?php  
/* =============================================
Plugin Name:        Sticky Social Link
Plugin URI:         http://habibcoder.com/stickysocial
Author:             HabibCoder
Author URI:         http://habibcoder.com
Version:            1.0.0
Requires at least:  6.0
Tested up to:       6.2
Requires PHP:       7.0
License:            General Public License
License URI:        http://www.gnu.org/licenses/gpl-2.0.html
Tags:               sticky social link, Sticky Social Link, Sticky Social, floating social link, floating social, floating social share, sticky social share, habibcoder
Description:        This is a Sticky/Floating Social Link Plugin. You can add your social links in your WordPress Website easily with more functionality. Your social links will be floating on your website.
Text Domain:        sticky-social-link
============================================= */

// ABSPATH Defined
if(!defined('ABSPATH')){
	exit('not valid');
}


/* ==========================
	Register Text Domain
========================== */
add_action('plugins_loaded', 'sslink_load_textdomain');
function sslink_load_textdomain(){
    load_plugin_textdomain('sticky-social-link', false, dirname(plugin_basename( __FILE__ ) ) . '/languages');
}


/* ==================================================
	Get Plugin Directory & URL and Define Constant
================================================== */
//Get plugin Dir & Url
$sslink_dir = plugin_dir_path( __FILE__ ); 
$sslink_url = plugin_dir_url( __FILE__ );

//Define Dir & Url as a Constants
define( 'SSLINK_PLUGIN_DIR', $sslink_dir );
define( 'SSLINK_PLUGIN_URL', $sslink_url );


/* ==========================
	Requires File
========================== */
// Dashboard Require
$sslink_admin_dir = SSLINK_PLUGIN_DIR .'dashboard/sslink-admin.php';
if(file_exists( $sslink_admin_dir )){
	require_once( $sslink_admin_dir );
}
// Frontend
$sslink_frontend_dir = SSLINK_PLUGIN_DIR .'frontend/sslink-frontend.php';
if(file_exists( $sslink_frontend_dir )){
	require_once( $sslink_frontend_dir );
}


/* ============================
	Enqueue in Admin Panel
============================ */
add_action('admin_enqueue_scripts', 'sslink_admin_enqueues');
function sslink_admin_enqueues(){
    // Scripts
    wp_enqueue_script('jquery-ui-tabs');
    wp_enqueue_script('stikcy-social-link-scripts', PLUGINS_URL('js/sslink-admin.js', __FILE__), array('jquery'), '1.0.0', true);
    // Style
	wp_enqueue_style('sticky-social-link-style', PLUGINS_URL('css/sslink-admin.css', __FILE__), array(), '1.0.0', 'all');
}

/* ============================
	Enqueue in Frontend
============================ */
add_action('wp_enqueue_scripts', 'sslink_frontend_enqueues');
function sslink_frontend_enqueues(){
    wp_enqueue_style('stikcy-social-link-style', PLUGINS_URL('css/sslink-frontend.css', __FILE__), array(), '1.0.0', 'all');
}


/* ==========================
	Redirect to plugin
========================== */
register_activation_hook( __FILE__, 'sslink_plugin_activation' );
function sslink_plugin_activation(){
    add_option('sslink_plugin_do_activate', true);
}

add_action('admin_init', 'sslink_plugin_redirect');
function sslink_plugin_redirect(){
    if (is_admin() && get_option('sslink_plugin_do_activate', false)) {
        delete_option('sslink_plugin_do_activate');

        if (!isset($_GET['active_multi'])) {
            wp_safe_redirect( admin_url('admin.php?page=sticky-social-link') );
            exit;
        }

    }
};


/* ==========================
	Frontend Dynamic Style
========================== */
add_action('wp_head', 'sslink_dynamic_styles');
function sslink_dynamic_styles(){ ?> 
<!-- Sticky Social Link Dynamic Style --> 
<style>
    :root{
        --sslinkPrimaryColor: <?php print get_option('sslink-menubgcolor'); ?>;
        --sslinkSecondaryColor: <?php print get_option('sslink-iconbgcolor'); ?>;
        --sslinkBlackColor: <?php print get_option('sslink-iconhovercolor'); ?>;
    }
<?php if(get_option('sslink-roundcorner') == 'corner') : ?>
    .sslink-socials ul li a{
        border-radius: 5px !important;
    }
<?php endif; ?>
<?php if(get_option('sslink-position') == 'left') : ?>
    .sslink-socials{
        right: auto !important;
        left: 0px !important;
    }
    .sslink-socials ul li {
        padding: 3px 6px 3px 5px !important;
    }
<?php endif; ?>
<?php if(get_option('sslink-position') == 'bottom') : ?>
    .sslink-socials{
        top: auto  !important;
        right: auto  !important;
        bottom: 0  !important;
        left: 50%  !important;
        -webkit-transform: translateX(-50%)  !important;
            -ms-transform: translateX(-50%)  !important;
                transform: translateX(-50%)  !important;
    }
    .sslink-socials ul{
        -webkit-box-orient: horizontal !important;
        -webkit-box-direction: normal !important;
            -ms-flex-direction: row !important;
                flex-direction: row !important;
        padding: 4px !important;
    }
    .sslink-socials ul li {
        padding: 2px 3px !important;
    }
<?php endif; ?>    
</style>
<?php
}