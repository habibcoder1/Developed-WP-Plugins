=== Sticky Social Link ===
Contributors: HabibCoder
Donate link: https://www.buymeacoffee.com/habibcoder
Tags: sticky social link, Sticky Social Link, Sticky Social, floating social link, floating social, floating social share, sticky social share, habibcoder
Requires at least: 6.0
Tested up to: 6.2
Stable tag: 1.0.0
Requires PHP: 7.0
License: GNU General Public License v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

**Sticky Social Link** is Floating/Sticky Social Link WordPress Plugin. If you want to add your add social links in your website as sticky/floating menu, you can use this Plugin. It is a simple WordPress Plugin with more functionality. You can add 20 social link by this Plugin.

== Description ==

**Sticky Social Link** is a WordPress Popular Plugin for adding a floating social link menu in your WP Website. You can add 20 social link in your website for contacting with you by your social link. You can change floating/sticky menu background color, icons color and icon hover color. If you want to move the social link menu, you can do this also. You can move the social link menu like Right side, Left side and at Botton of your website. It's easy to use this plugin in your WordPress Website.

== Docs and Support ==

You can find [Docs](https://habibcoder.com/stickysocial) here and more detailed information about Right Click Disable for Secure Plugin. When you cannot find the answer to your question on the FAQ or in any of the documentation, check the [support forum](https://wordpress.org/support/plugin/sticky-social-link) on WordPress.org. 

== Sticky Social Link Need Support ==

It is hard to continue development and support for this free plugin without contributions from users like you. If you enjoy using HR Scroll Top and find it useful, please consider [making a donation](https://www.buymeacoffee.com/habibcoder). Your donation will help encourage and support the plugin's continued development and better user support.

== Features ==
* Add Social Links
* 20 Social Links option
* Social Link Menu moving
* Menu background color change option
* Icons Background color change option
* Icons Hover color change option
* Move to Right side, Left side and at bottom
* Don't load extra codes
* Hand Coding Plugin
* No use of any Framework/Library
* Light Weight Plugin
* Author Contact info, If you face any problems.

== Frequently Asked Questions ==

= Is this light weight plugin? =

Yes, this is a light weight WordPress Plugin.

= May I move the Social Link Menu position? =

No, you can move Right side, Left side and at Bottom.

= Is it user-friendly? =

Yes, it is a user-friendly plugin.

= Is will increase loading time after adding this plugin in my website? =

No, Your website will not increase loading time after adding this plugin. You can use this plugin without any hesitation.

== Screenshots ==

1. Screenshot-1.png
2. Screenshot-2.png
3. Screenshot-3.png
4. Screenshot-4.png
5. Screenshot-5.png
6. Screenshot-6.png
7. Screenshot-7.png

== Changelog ==

= 1.0.0 =
* A new version

== Upgrade Notice ==
No need to upgrade this plugin because of this plugin is free totally.


== Usage The Plugin ==
You can use this plugin with some steps, like:

* Search and Install the Sticky Social Link. You will be redirected to the plugin admin page after installing it.
* You can change everything from here like more social link adding option. Social link menu position, background color, icons and hover color option etc.
*  Then you go to your website and when you will see the social link menu at your chosen postion in your website.

== Installation ==

= Minimum Requirements =
* WordPress 5.0 or greater
* PHP version 7.0 or greater
* MySQL version 5.0 or greater

= UPDATING =

Automatic updates should work seamlessly. We always suggest you backup your website before any automated update to avoid unforeseen problems.

== Benefit ==
An awesome sticky/floating social link menu will add on your website.
