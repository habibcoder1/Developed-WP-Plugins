<?php  
/**
 * @package Sticky Social Link
 * 
 * Sticky Social Link Dashboard Details
 */

// ABSPATH Defined
if(!defined('ABSPATH')){
	exit('not valid');
}


add_action('admin_menu', 'sslink_admin_menu');
function sslink_admin_menu(){
    add_menu_page( 'Sticky Social Link', 'Sticky Social Link', 'manage_options', 'sticky-social-link', 'sslink_option_callback', SSLINK_PLUGIN_URL .'img/sslink.png', 25);
}

// Menu Option Callback
function sslink_option_callback(){ ?>
    
    <div class="sslink-option">
        <div class="container">
            <!-- Plugin Form -->
            <div class="sslink-form">
                <div class="sslink-title">
                    <h2><?php esc_html_e('Sticky Social Link Option', 'sticky-social-link'); ?></h2>
                </div>
                <div class="sslink-tabs">
                    <ul class="sslink-menu">
                        <li><a href="#social-icons"><?php esc_html_e('Social Links', 'sticky-social-link'); ?></a></li>
                        <li><a href="#social-style"><?php esc_html_e('Settings', 'sticky-social-link'); ?></a></li>
                    </ul>
                    <div id="social-icons">
                        <form action="options.php" method="POST">
                            <?php wp_nonce_field('update-options'); ?>
                            <!-- Facebook -->
                            <label for="sslinkfb" class="first-label"><?php esc_html_e('Facebook', 'sticky-social-link'); ?></label>
                            <small><?php esc_html_e('Like: https://facebook.com/habibcoder1', 'sticky-social-link'); ?></small>
                            <input type="text" name="sslinkfb" id="sslinkfb" placeholder="full url here" value="<?php esc_url(print get_option('sslinkfb')); ?>">
                            <!-- Twitter -->
                            <label for="sslinktwitter"><?php esc_html_e('Twitter', 'sticky-social-link'); ?></label>
                            <input type="text" name="sslinktwitter" id="sslinktwitter" placeholder="full url here" value="<?php esc_url(print get_option('sslinktwitter')); ?>">
                            <!-- Instagram -->
                            <label for="sslinkinsta"><?php esc_html_e('Instagram', 'sticky-social-link'); ?></label>
                            <input type="text" name="sslinkinsta" id="sslinkinsta" placeholder="full url here" value="<?php esc_url(print get_option('sslinkinsta')); ?>">
                            <!-- LinkedIn -->
                            <label for="sslinklinkedin"><?php esc_html_e('LinkedIn', 'sticky-social-link'); ?></label>
                            <input type="text" name="sslinklinkedin" id="sslinklinkedin" placeholder="full url here" value="<?php esc_url(print get_option('sslinklinkedin')); ?>">
                            <!-- Youtube -->
                            <label for="sslinkyoutube"><?php esc_html_e('Youtube', 'sticky-social-link'); ?></label>
                            <input type="text" name="sslinkyoutube" id="sslinkyoutube" placeholder="full url here" value="<?php esc_url(print get_option('sslinkyoutube')); ?>">
                            <!-- Behance -->
                            <label for="sslinkbehance"><?php esc_html_e('Behance', 'sticky-social-link'); ?></label>
                            <input type="text" name="sslinkbehance" id="sslinkbehance" placeholder="full url here" value="<?php esc_url(print get_option('sslinkbehance')); ?>">
                            <!-- Pinterest -->
                            <label for="sslinkpinterest"><?php esc_html_e('Pinterest', 'sticky-social-link'); ?></label>
                            <input type="text" name="sslinkpinterest" id="sslinkpinterest" placeholder="full url here" value="<?php esc_url(print get_option('sslinkpinterest')); ?>">
                            <!-- TikTok -->
                            <label for="sslinktiktok"><?php esc_html_e('TikTok', 'sticky-social-link'); ?></label>
                            <input type="text" name="sslinktiktok" id="sslinktiktok" placeholder="full url here" value="<?php esc_url(print get_option('sslinktiktok')); ?>">
                            <!-- WhatsApp -->
                            <label for="sslinkwhatsapp"><?php esc_html_e('WhatsApp', 'sticky-social-link'); ?></label>
                            <input type="text" name="sslinkwhatsapp" id="sslinkwhatsapp" placeholder="WhatsApp number with country code" value="<?php esc_url(print get_option('sslinkwhatsapp')); ?>">
                            <!-- Messenger -->
                            <label for="sslinkmessenger"><?php esc_html_e('Messenger', 'sticky-social-link'); ?></label>
                            <input type="text" name="sslinkmessenger" id="sslinkmessenger" placeholder="facebook username or profile id" value="<?php esc_url(print get_option('sslinkmessenger')); ?>">
                            <!-- Telegram -->
                            <label for="sslinktelegram"><?php esc_html_e('Telegram', 'sticky-social-link'); ?></label>
                            <input type="text" name="sslinktelegram" id="sslinktelegram" placeholder="Telegram username only" value="<?php esc_url(print get_option('sslinktelegram')); ?>">
                            <!-- WeChat -->
                            <label for="sslinkwechat"><?php esc_html_e('WeChat', 'sticky-social-link'); ?></label>
                            <input type="text" name="sslinkwechat" id="sslinkwechat" placeholder="full url here" value="<?php esc_url(print get_option('sslinkwechat')); ?>">
                            <!-- Viber -->
                            <label for="sslinkviber"><?php esc_html_e('Viber', 'sticky-social-link'); ?></label>
                            <input type="text" name="sslinkviber" id="sslinkviber" placeholder="Viber public account URI" value="<?php esc_url(print get_option('sslinkviber')); ?>">
                            <!-- Email -->
                            <label for="sslinkemail"><?php esc_html_e('Email', 'sticky-social-link'); ?></label>
                            <input type="text" name="sslinkemail" id="sslinkemail" placeholder="type your email here" value="<?php esc_url(print get_option('sslinkemail')); ?>">
                            <!-- Dribbble -->
                            <label for="sslinkdribbble"><?php esc_html_e('Dribbble', 'sticky-social-link'); ?></label>
                            <input type="text" name="sslinkdribbble" id="sslinkdribbble" placeholder="full url here" value="<?php esc_url(print get_option('sslinkdribbble')); ?>">
                            <!-- Reddit -->
                            <label for="sslinkreddit"><?php esc_html_e('Reddit', 'sticky-social-link'); ?></label>
                            <input type="text" name="sslinkreddit" id="sslinkreddit" placeholder="full url here" value="<?php esc_url(print get_option('sslinkreddit')); ?>">
                            <!-- Snapchat -->
                            <label for="sslinksnapchat"><?php esc_html_e('Snapchat', 'sticky-social-link'); ?></label>
                            <input type="text" name="sslinksnapchat" id="sslinksnapchat" placeholder="full url here" value="<?php esc_url(print get_option('sslinksnapchat')); ?>">
                            <!-- Medium -->
                            <label for="sslinkmedium"><?php esc_html_e('Medium', 'sticky-social-link'); ?></label>
                            <input type="text" name="sslinkmedium" id="sslinkmedium" placeholder="full url here" value="<?php esc_url(print get_option('sslinkmedium')); ?>">
                            <!-- Quora -->
                            <label for="sslinkquora"><?php esc_html_e('Quora', 'sticky-social-link'); ?></label>
                            <input type="text" name="sslinkquora" id="sslinkquora" placeholder="full url here" value="<?php esc_url(print get_option('sslinkquora')); ?>">
                            <!-- Tumblr -->
                            <label for="sslinktumblr"><?php esc_html_e('Tumblr', 'sticky-social-link'); ?></label>
                            <input type="text" name="sslinktumblr" id="sslinktumblr" placeholder="full url here" value="<?php esc_url(print get_option('sslinktumblr')); ?>">

                            <input type="hidden" name="action" value="update">
                            <input type="hidden" name="page_options" value="sslinkfb, sslinktwitter, sslinkinsta, sslinklinkedin, sslinkyoutube, sslinkbehance, sslinkpinterest, sslinktiktok, sslinkwhatsapp, sslinkmessenger, sslinktelegram, sslinkwechat, sslinkviber, sslinkemail, sslinkdribbble, sslinkreddit, sslinksnapchat, sslinkmedium, sslinkquora, sslinktumblr">
                            <input type="submit" value="Save Changes">
                        </form>
                    </div>
                    <div id="social-style">
                        <form action="options.php" method="POST">
                            <?php wp_nonce_field('update-options'); ?>
                            
                            <p class="sslink-postion-p"><?php esc_html_e('Social Link Position', 'sticky-social-link'); ?></p>
                            <small><?php esc_html_e('Default: Right', 'sticky-social-link'); ?></small>
                            <div class="sslink-right">
                                <input type="radio" name="sslink-position" id="sslink-rightposition" value="right" <?php if(get_option('sslink-position') == 'right'){echo esc_attr('checked="checked"');} ?> >
                                <label for="sslink-rightposition"><?php esc_html_e('Right', 'sticky-social-link'); ?></label>
                            </div>
                            <div class="sslink-left">
                                <input type="radio" name="sslink-position" id="sslink-leftposition" value="left" <?php if(get_option('sslink-position') == 'left'){echo esc_attr('checked="checked"');} ?>>
                                <label for="sslink-leftposition"><?php esc_html_e('Left', 'sticky-social-link'); ?></label>
                            </div>
                            <div class="sslink-bottom">
                                <input type="radio" name="sslink-position" id="sslink-bottomposition" value="bottom" <?php if(get_option('sslink-position') == 'bottom'){echo esc_attr('checked="checked"');} ?>>
                                <label for="sslink-bottomposition"><?php esc_html_e('Bottom', 'sticky-social-link'); ?></label>
                            </div>
                            <label for="sslink-menubgcolor" style="margin-bottom:0;"><?php esc_html_e('Icons Menu Background Color', 'sticky-social-link'); ?></label>
                            <small><?php esc_html_e('Default: #000000', 'sticky-social-link'); ?></small>
                            <input type="color" name="sslink-menubgcolor" id="sslink-menubgcolor" value="<?php esc_url(print get_option('sslink-menubgcolor')); ?>">
                            <label for="sslink-iconbgcolor" style="margin-bottom:0;"><?php esc_html_e('Icons Background Color', 'sticky-social-link'); ?></label>
                            <small><?php esc_html_e('Default: #000000', 'sticky-social-link'); ?></small>
                            <input type="color" name="sslink-iconbgcolor" id="sslink-iconbgcolor" value="<?php esc_url(print get_option('sslink-iconbgcolor')); ?>">
                            <label for="sslink-iconhovercolor" style="margin-bottom:0;"><?php esc_html_e('Icons Hover Color', 'sticky-social-link'); ?></label>
                            <small><?php esc_html_e('Default: #000000', 'sticky-social-link'); ?></small>
                            <input type="color" name="sslink-iconhovercolor" id="sslink-iconhovercolor" value="<?php esc_url(print get_option('sslink-iconhovercolor')); ?>">
                            
                            <label for="sslink-roundcorner" style="margin-bottom:0;"><?php esc_html_e('Icons Round or Corner Style', 'sticky-social-link'); ?></label>
                            <small><?php esc_html_e('Default: Round', 'sticky-social-link'); ?></small>
                            <select name="sslink-roundcorner" id="sslink-roundcorner">
                                <option value="round" <?php if(get_option('sslink-roundcorner') == 'round'){echo esc_attr('selected="selected"');} ?> ><?php esc_html_e('Round', 'sticky-social-link'); ?></option>
                                <option value="corner" <?php if(get_option('sslink-roundcorner') == 'corner'){echo esc_attr('selected="selected"');} ?> ><?php esc_html_e('Corner', 'sticky-social-link'); ?></option>
                            </select>

                            <input type="hidden" name="action" value="update">
                            <input type="hidden" name="page_options" value="sslink-position, sslink-menubgcolor, sslink-iconbgcolor, sslink-iconhovercolor, sslink-roundcorner">
                            <input type="submit" value="Save Changes">
                        </form>
                    </div>
                </div>
            </div>
            <!-- Author Details -->
            <div class="sslink-author">
                <div class="sslink-title">
                    <h2><?php esc_html_e('Author', 'sticky-social-link'); ?></h2>
                </div>
                <div class="author-img">
                    <img src="<?php echo esc_url(SSLINK_PLUGIN_URL . 'img/habibcoder.jpg'); ?>" alt="HabibCoder">
                </div>
                <h4 class="author-name"> <?php esc_html_e('HabibCoder', 'sticky-social-link'); ?> </h4>
                <div class="author-description">
                    <p><?php esc_html_e('I\'m ', 'sticky-social-link'); ?><a href="<?php echo esc_url('http://habibcoder.com'); ?>" target="_blank"><?php esc_html_e('Habibur Rahman', 'sticky-social-link') ?></a> <?php esc_html_e('and a Professional Web Developer and Web Designer. For the last some years, I\'m working in this field with national and international clients. I have done many more projects with client satisfaction.', 'sticky-social-link'); ?><br>
                    <?php esc_html_e('This is an open-source WordPress Plugin. If you want to support me, You can', 'sticky-social-link'); ?> <b><?php esc_html_e('click on the Buy Me a Coffe Button', 'sticky-social-link'); ?></b>. <br> <?php esc_html_e('Thank You !.', 'sticky-social-link'); ?> </p>
                </div>
                <div class="donate-btn">
                    <a href="<?php echo esc_url('https://www.buymeacoffee.com/habibcoder'); ?>" target="_blank">
                    <h4><span>🍦</span><?php esc_html_e('Buy Me A Coffee', 'sticky-social-link'); ?></h4>
                    </a>
                </div>
                <h3 class="social-title"> 
                    <?php esc_html_e('Follow Me', 'sticky-social-link'); ?>
                </h3>
                <div class="social-icons">
                    <a class="facebook" title="Facebook" href="<?php echo esc_url('http://facebook.com/habibcoder1'); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL . 'img/sslink-facebook.png'); ?>" alt="facebook"></a>
                    <a class="linkedin" title="LinkedIn" href="<?php echo esc_url('http://linkedin.com/in/habibcoder'); ?>" target="_blank"><img src="<?php echo esc_url(SSLINK_PLUGIN_URL . 'img/sslink-linkedin.png'); ?>" alt="LinkedIn"></a>
                    <a class="instagram" title="Instagram" href="<?php echo esc_url('http://instagram.com/habibcoder'); ?>" target="_blank"><img src="<?php echo esc_url(SSLINK_PLUGIN_URL . 'img/sslink-instagram.png'); ?>" alt="instagram"></a>
                    <a class="website" title="Website" href="<?php echo esc_url('http://habibcoder.com'); ?>" target="_blank"><img src="<?php echo esc_url(SSLINK_PLUGIN_URL . 'img/website.png'); ?>" alt="HabibCoder"></a>
                </div>
                <div class="thank-you">
                    <span>♥</span>
                    <h5><?php esc_html_e('Thank You', 'sticky-social-link'); ?></h5>
                    <span>♥</span>
                </div>
            </div>
        </div>
    </div>

<?php
}