<?php  
/**
 * @package Sticky Social Link
 * 
 * Sticky Social Link Frontend Details
 */

 // ABSPATH Defined
if(!defined('ABSPATH')){
	exit('not valid');
}


/* ==========================
	Social Icons
========================== */
add_action('wp_footer', 'sslink_social_links_add');
function sslink_social_links_add(){ ?>
   
    <div class="sslink-socials">
        <ul class="sslink-menu">
            <?php if(!empty(get_option('sslinkfb'))) : ?>
            <li class="facebook"><a title="Facebook" href="<?php esc_url(print get_option('sslinkfb')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-facebook.png'); ?>" alt="facebook"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sslinktwitter'))) : ?>
            <li class="twitter"><a title="Twitter" href="<?php esc_url(print get_option('sslinktwitter')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-twitter.png'); ?>" alt="twitter"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sslinkinsta'))) : ?>
            <li class="instagram"><a title="Instagram" href="<?php esc_url(print get_option('sslinkinsta')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-instagram.png'); ?>" alt="instagram"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sslinklinkedin'))) : ?>
            <li class="linkedin"><a title="LinkedIn" href="<?php esc_url(print get_option('sslinklinkedin')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-linkedin.png'); ?>" alt="linkedin"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sslinkyoutube'))) : ?>
            <li class="youtube"><a title="YouTube" href="<?php esc_url(print get_option('sslinkyoutube')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-youtube.png'); ?>" alt="youtube"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sslinkbehance'))) : ?>
            <li class="behance"><a title="Behance" href="<?php esc_url(print get_option('sslinkbehance')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-behance.png'); ?>" alt="behance"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sslinkpinterest'))) : ?>
            <li class="pinterest"><a title="Pinterest" href="<?php esc_url(print get_option('sslinkpinterest')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-pinterest.png'); ?>" alt="pinterest"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sslinktiktok'))) : ?>
            <li class="tiktok"><a title="TikTok" href="<?php esc_url(print get_option('sslinktiktok')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-tiktok.png'); ?>" alt="tiktok"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sslinkwhatsapp'))) : ?>
            <li class="whatsapp"><a title="WhatsApp" href="https://web.whatsapp.com/send?phone=<?php esc_url(print get_option('sslinkwhatsapp')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-whatsapp.png'); ?>" alt="whatsapp"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sslinkmessenger'))) : ?>
            <li class="messenger"><a title="Messenger" href="http://m.me/<?php esc_url(print get_option('sslinkmessenger')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-messenger.png'); ?>" alt="messenger"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sslinktelegram'))) : ?>
            <li class="telegram"><a title="Telegram" href="https://t.me/<?php esc_url(print get_option('sslinktelegram')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-telegram.png'); ?>" alt="telegram"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sslinkwechat'))) : ?>
            <li class="wechat"><a title="WeChat" href="<?php esc_url(print get_option('sslinkwechat')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-wechat.png'); ?>" alt="wechat"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sslinkviber'))) : ?>
            <li class="viber"><a title="Viber" href="viber://pa?chatURI=<?php esc_url(print get_option('sslinkviber')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-viber.png'); ?>" alt="viber"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sslinkemail'))) : ?>
            <li class="email"><a title="Email" href="mailto:<?php esc_url(print get_option('sslinkemail')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-email.png'); ?>" alt="email"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sslinkdribbble'))) : ?>
            <li class="dribbble"><a title="Dribbble" href="<?php esc_url(print get_option('sslinkdribbble')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-dribbble.png'); ?>" alt="dribbble"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sslinkreddit'))) : ?>
            <li class="reddit"><a title="Reddit" href="<?php esc_url(print get_option('sslinkreddit')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-reddit.png'); ?>" alt="reddit"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sslinksnapchat'))) : ?>
            <li class="snapchat"><a title="Snapchat" href="<?php esc_url(print get_option('sslinksnapchat')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-snapchat.png'); ?>" alt="snapchat"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sslinkmedium'))) : ?>
            <li class="medium"><a title="Medium" href="<?php esc_url(print get_option('sslinkmedium')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-medium.png'); ?>" alt="medium"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sslinkquora'))) : ?>
            <li class="quora"><a title="Quora" href="<?php esc_url(print get_option('sslinkquora')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-quora.png'); ?>" alt="quora"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sslinktumblr'))) : ?>
            <li class="tumblr"><a title="Tumblr" href="<?php esc_url(print get_option('sslinktumblr')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-tumblr.png'); ?>" alt="tumblr"></a></li>
            <?php endif; ?>
        </ul>
    </div>

<?php
}