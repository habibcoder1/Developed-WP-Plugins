;(function($){
    'use strict';

    jQuery(document).ready(function(){
        /* =================================
         Go To Website Link New Tab Open
        ================================= */        
        jQuery('body.login #login #backtoblog a').attr('target', '_blank');
    
    });

}(jQuery));