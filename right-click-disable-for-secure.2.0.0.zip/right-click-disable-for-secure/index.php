<?php 
/*
	Nothing Here. Only foolish people want to redirect index page
*/