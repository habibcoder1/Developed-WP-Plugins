=== Right Click Disable for Secure ===
Contributors: HabibCoder
Donate link: https://www.buymeacoffee.com/habibcoder
Tags: right click disable for secure, right click disable, hr right click disable, wp secure, wp website secure, website security, click disable, rcd, rcd for secure, website security, secure website
Requires at least: 6.0
Tested up to: 6.1.1
Stable tag: 2.0.0
Requires PHP: 7.0
License: GNU General Public License v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

**Right Click Disable for Secure** is WordPress Website Secure Plugin. If you want more security for your website then we can use this plugin. This plugin has more options like with or without alert text & some keys disable options for security purposes.

== Description ==

**Right Click Disable for Secure** is WordPress Website Secure Plugin with more functionality. Right Click Disable for Secure plguin has more opitons like Right Click disable alert text or without alert text. Some important keys disable options have also for your website security purpose. Right Click Disable for Secure has F12, Ctrl+Shift+I, Ctrl+Shift+C, Ctrl+Shift+J and Ctrl+U keys disable or enable options. These keys are important for secure your website.

== Docs and Support ==

You can find [Docs](https://habibcoder.com/rclick-disable/) here and more detailed information about Right Click Disable for Secure Plugin. When you cannot find the answer to your question on the FAQ or in any of the documentation, check the [support forum](https://wordpress.org/support/plugin/right-click-disable-for-secure/) on WordPress.org. 

== Right Click Disable for Secure Need Support ==

It is hard to continue development and support for this free plugin without contributions from users like you. If you enjoy using HR Scroll Top and find it useful, please consider [making a donation](https://www.buymeacoffee.com/habibcoder). Your donation will help encourage and support the plugin's continued development and better user support.

== Features ==
* Right Click Disable
* Right Click Disable with alert text option
* Right Click Disable without alert text option
* F12 key enable/disable option for security
* Ctrl+Shift+I key enable/disable option for security
* Ctrl+Shift+J key enable/disable option for security
* Ctrl+Shift+C key enable/disable option for security
* Ctrl+U key enable/disable option for security
* Hand Coding Plugin
* No use of any Framework/Library
* Light Weight Plugin
* Author Contact info, If you face any problems.

== Frequently Asked Questions ==

= Really, Is it give more secure for my website? =

Yes, Your website will be more secure.

= May I use right-click functionality after activating this plugin? =

No, your right click will disable.

= Is it user-friendly? =

Yes, it is a user-friendly plugin.

= Is this pluign is light weight? =

Yes, this is a light weight plugin.

= Is it possible to disable some security keys =

Yes, you can disable F12, Ctrl+Shift+I, Ctrl+Shift+J, Ctrl+Shift+C, Ctrl+U these keys for increasing your website security.

== Screenshots ==

1. Screenshot-1.png
2. Screenshot-2.png
3. Screenshot-3.png
4. Screenshot-4.png
5. Screenshot-5.png
6. Screenshot-6.png
7. Screenshot-7.png

== Changelog ==

= 1.0.0 =
* A new version

= 1.1.0 =
* Some codes changed, Author name changed and Version updated

= 2.0.0 =
* Added plugin functionality option
* Added alert text option
* Added F12 Disable option
* Added Ctrl+Shift+I Disable option
* Added Ctrl+Shift+J Disable option
* Added Ctrl+Shift+C Disable option
* Added Ctrl+U Disable option


== Upgrade Notice ==
No need to upgrade this plugin because of this plugin is free totally.


== Usage The Plugin ==
You can use this plugin with some steps, like:

* Search and Install the Right Click Disable for Secure Plugin. You will be redirected to the plugin admin page after installing it.
* You can change everything from here like Right Click Disable with alert text or without alert text, Alert text change option and some important keys Disable/Enable option.
*  Then you go to your website and when you want to click on right mouse button, you will not capable for clicking the right button.

== Installation ==

= Minimum Requirements =
* WordPress 5.0 or greater
* PHP version 7.0 or greater
* MySQL version 5.0 or greater

= UPDATING =

Automatic updates should work seamlessly. We always suggest you backup your website before any automated update to avoid unforeseen problems.

== Benefit ==
Right Click & Some keys will be disabled on your website.
