=== Ultimate Social Share Buttons ===
Contributors: HabibCoder
Donate link: https://www.buymeacoffee.com/habibcoder
Tags: ultimate social share buttons, social sharing button, social share button, social share, social media share button, social media, social link share, social media share, share button, habibcoder, habib coder
Requires at least: 6.0
Tested up to: 6.3
Stable tag: 1.0.0
Requires PHP: 7.0
License: General Public License v-2.0 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

**Ultimate Social Share Buttons** is a most useful Social Media Share Plugin in your blog page and single page. It is unique social sharing plugin. Ultimate Social Share buttons has more functionality.

== Description ==

You can easyly add social media in your website by using **Ultimate Social Share Buttons** plugin for share your posts/pages/website. It is responsible and light weight plugin. This is a most useful Social Media Share Plugin in your blog page and single page. It is unique social sharing plugin. Ultimate Social Share buttons has more functionality.

== Docs and Support ==

You can find [Docs](https://habibcoder.com/socialshare) here and more detailed information about Ultimate Social Share Buttons WordPress Plugin. When you cannot find the answer to your question on the FAQ or in any of the documentation, check the [support forum](https://wordpress.org/support/plugin/ultimate-social-share-buttons) on WordPress.org. 

== Ultimate Social Share Buttons Need Support ==

It is hard to continue development and support for this free plugin without contributions from users like you. If you enjoy using Ultimate Social Share Buttons and find it useful, please consider [making a donation](https://www.buymeacoffee.com/habibcoder). Your donation will help encourage and support the plugin's continued development and better user support.

== Features ==
* Social Share buttons
* Add Social Media for Sharing your website
* Add social media link to share your website posts
* Add Facebook, Instagram, Twitter, LinkedIn, YouTube, Telegram, WhatsApp, Pinterest, Tumblr and more.
* Easyly add your social media to share in your website

== Frequently Asked Questions ==

= May I add Popular Social Media to share my posts? =

Yes, you can add popular and more social media to share your posts/page and ohters things.

= Is this light weight plugin? =

Yes, this is a light weight WordPress Plugin.

= Is this plugin responsible for mobile and tablet? =

Yes, this is responsive in the mobile and tablet.

= Is it user-friendly? =

Yes, it is a user-friendly plugin.

= Is will increase loading time after adding this plugin in my website? =

No, Your website will not increase loading time after adding this plugin. You can use this plugin without any hesitation.

== Screenshots ==

1. Screenshot-1.png

== Changelog ==

= 1.0.0 =
* A new version

== Upgrade Notice ==
No need to upgrade this plugin because of this plugin is free totally.


== Usage The Plugin ==
You can use this plugin with some steps, like:

* Search and Install the Ultmate Social Share Buttons. You will be redirected to the plugin admin page after installing it.
* You can add your social media link that you want to share the posts.
*  Then you go to your website and when you will see your social media added in your website.

== Installation ==

= Minimum Requirements =
* WordPress 6.0 or greater
* PHP version 7.0 or greater
* MySQL version 5.0 or greater

= UPDATING =

Automatic updates should work seamlessly. We always suggest you backup your website before any automated update to avoid unforeseen problems.

== Benefit ==
Easyly add your website posts/page in your social media. Visitors/Customrs will grow for using this plugin
