<?php  
// silence is golden