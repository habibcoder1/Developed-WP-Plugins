(function($){
    'use strict';
    jQuery(document).ready(function(){

        jQuery('.ssb-tab').tabs();
        
    });
})(jQuery);