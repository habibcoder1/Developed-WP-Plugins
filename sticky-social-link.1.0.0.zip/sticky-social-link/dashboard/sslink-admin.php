<?php  
/**
 * @package Sticky Social Link
 * 
 * Sticky Social Link Dashboard Details
 */

// ABSPATH Defined
if(!defined('ABSPATH')){
	exit('not valid');
}


add_action('admin_menu', 'sslink_admin_menu');
function sslink_admin_menu(){
    add_menu_page( 'Sticky Social Link', 'Sticky Social Link', 'manage_options', 'sticky-social-link', 'sslink_option_callback', SSLINK_PLUGIN_URL .'img/sslink.png', 25);
}

// Menu Option Callback
function sslink_option_callback(){ ?>
    
    <div class="sslink-option">
        <div class="container">
            <!-- Plugin Form -->
            <div class="sslink-form">
                <div class="sslink-title">
                    <h2><?php esc_html_e('Sticky Social Link Option', 'sticky-social-link'); ?></h2>
                </div>
                <div class="sslink-tabs">
                    <ul class="sslink-menu">
                        <li><a href="#social-icons"><?php esc_html_e('Social Links', 'sticky-social-link'); ?></a></li>
                        <li><a href="#social-style"><?php esc_html_e('Settings', 'sticky-social-link'); ?></a></li>
                    </ul>
                    <div id="social-icons">
                        <form action="options.php" method="POST">
                            <?php wp_nonce_field('update-options'); ?>
                            <!-- Facebook -->
                            <label for="sticky-slink-fb" class="first-label"><?php esc_html_e('Facebook', 'sticky-social-link'); ?></label>
                            <small><?php esc_html_e('Like: https://facebook.com/habibcoder1', 'sticky-social-link'); ?></small>
                            <input type="text" name="sticky-slink-fb" id="sticky-slink-fb" placeholder="full url here" value="<?php esc_url(print get_option('sticky-slink-fb')); ?>">
                            <!-- Twitter -->
                            <label for="sticky-slink-twitter"><?php esc_html_e('Twitter', 'sticky-social-link'); ?></label>
                            <input type="text" name="sticky-slink-twitter" id="sticky-slink-twitter" placeholder="full url here" value="<?php esc_url(print get_option('sticky-slink-twitter')); ?>">
                            <!-- Instagram -->
                            <label for="sticky-slink-insta"><?php esc_html_e('Instagram', 'sticky-social-link'); ?></label>
                            <input type="text" name="sticky-slink-insta" id="sticky-slink-insta" placeholder="full url here" value="<?php esc_url(print get_option('sticky-slink-insta')); ?>">
                            <!-- LinkedIn -->
                            <label for="sticky-slink-linkedin"><?php esc_html_e('LinkedIn', 'sticky-social-link'); ?></label>
                            <input type="text" name="sticky-slink-linkedin" id="sticky-slink-linkedin" placeholder="full url here" value="<?php esc_url(print get_option('sticky-slink-linkedin')); ?>">
                            <!-- Youtube -->
                            <label for="sticky-slink-youtube"><?php esc_html_e('Youtube', 'sticky-social-link'); ?></label>
                            <input type="text" name="sticky-slink-youtube" id="sticky-slink-youtube" placeholder="full url here" value="<?php esc_url(print get_option('sticky-slink-youtube')); ?>">
                            <!-- Behance -->
                            <label for="sticky-slink-behance"><?php esc_html_e('Behance', 'sticky-social-link'); ?></label>
                            <input type="text" name="sticky-slink-behance" id="sticky-slink-behance" placeholder="full url here" value="<?php esc_url(print get_option('sticky-slink-behance')); ?>">
                            <!-- Pinterest -->
                            <label for="sticky-slink-pinterest"><?php esc_html_e('Pinterest', 'sticky-social-link'); ?></label>
                            <input type="text" name="sticky-slink-pinterest" id="sticky-slink-pinterest" placeholder="full url here" value="<?php esc_url(print get_option('sticky-slink-pinterest')); ?>">
                            <!-- TikTok -->
                            <label for="sticky-slink-tiktok"><?php esc_html_e('TikTok', 'sticky-social-link'); ?></label>
                            <input type="text" name="sticky-slink-tiktok" id="sticky-slink-tiktok" placeholder="full url here" value="<?php esc_url(print get_option('sticky-slink-tiktok')); ?>">
                            <!-- WhatsApp -->
                            <label for="sticky-slink-whatsapp"><?php esc_html_e('WhatsApp', 'sticky-social-link'); ?></label>
                            <input type="text" name="sticky-slink-whatsapp" id="sticky-slink-whatsapp" placeholder="WhatsApp number with country code" value="<?php esc_url(print get_option('sticky-slink-whatsapp')); ?>">
                            <!-- Messenger -->
                            <label for="sticky-slink-messenger"><?php esc_html_e('Messenger', 'sticky-social-link'); ?></label>
                            <input type="text" name="sticky-slink-messenger" id="sticky-slink-messenger" placeholder="facebook username or profile id" value="<?php esc_url(print get_option('sticky-slink-messenger')); ?>">
                            <!-- Telegram -->
                            <label for="sticky-slink-telegram"><?php esc_html_e('Telegram', 'sticky-social-link'); ?></label>
                            <input type="text" name="sticky-slink-telegram" id="sticky-slink-telegram" placeholder="Telegram username only" value="<?php esc_url(print get_option('sticky-slink-telegram')); ?>">
                            <!-- WeChat -->
                            <label for="sticky-slink-wechat"><?php esc_html_e('WeChat', 'sticky-social-link'); ?></label>
                            <input type="text" name="sticky-slink-wechat" id="sticky-slink-wechat" placeholder="full url here" value="<?php esc_url(print get_option('sticky-slink-wechat')); ?>">
                            <!-- Viber -->
                            <label for="sticky-slink-viber"><?php esc_html_e('Viber', 'sticky-social-link'); ?></label>
                            <input type="text" name="sticky-slink-viber" id="sticky-slink-viber" placeholder="Viber public account URI" value="<?php esc_url(print get_option('sticky-slink-viber')); ?>">
                            <!-- Email -->
                            <label for="sticky-slinkeemail"><?php esc_html_e('Email', 'sticky-social-link'); ?></label>
                            <input type="text" name="sticky-slinkeemail" id="sticky-slinkeemail" placeholder="type your email here" value="<?php esc_url(print get_option('sticky-slinkeemail')); ?>">
                            <!-- Dribbble -->
                            <label for="sticky-slink-dribbble"><?php esc_html_e('Dribbble', 'sticky-social-link'); ?></label>
                            <input type="text" name="sticky-slink-dribbble" id="sticky-slink-dribbble" placeholder="full url here" value="<?php esc_url(print get_option('sticky-slink-dribbble')); ?>">
                            <!-- Reddit -->
                            <label for="sticky-slink-reddit"><?php esc_html_e('Reddit', 'sticky-social-link'); ?></label>
                            <input type="text" name="sticky-slink-reddit" id="sticky-slink-reddit" placeholder="full url here" value="<?php esc_url(print get_option('sticky-slink-reddit')); ?>">
                            <!-- Snapchat -->
                            <label for="sticky-slink-snapchat"><?php esc_html_e('Snapchat', 'sticky-social-link'); ?></label>
                            <input type="text" name="sticky-slink-snapchat" id="sticky-slink-snapchat" placeholder="full url here" value="<?php esc_url(print get_option('sticky-slink-snapchat')); ?>">
                            <!-- Medium -->
                            <label for="sticky-slink-medium"><?php esc_html_e('Medium', 'sticky-social-link'); ?></label>
                            <input type="text" name="sticky-slink-medium" id="sticky-slink-medium" placeholder="full url here" value="<?php esc_url(print get_option('sticky-slink-medium')); ?>">
                            <!-- Quora -->
                            <label for="sticky-slink-quora"><?php esc_html_e('Quora', 'sticky-social-link'); ?></label>
                            <input type="text" name="sticky-slink-quora" id="sticky-slink-quora" placeholder="full url here" value="<?php esc_url(print get_option('sticky-slink-quora')); ?>">
                            <!-- Tumblr -->
                            <label for="sticky-slink-tumblr"><?php esc_html_e('Tumblr', 'sticky-social-link'); ?></label>
                            <input type="text" name="sticky-slink-tumblr" id="sticky-slink-tumblr" placeholder="full url here" value="<?php esc_url(print get_option('sticky-slink-tumblr')); ?>">

                            <input type="hidden" name="action" value="update">
                            <input type="hidden" name="page_options" value="sticky-slink-fb, sticky-slink-twitter, sticky-slink-insta, sticky-slink-linkedin, sticky-slink-youtube, sticky-slink-behance, sticky-slink-pinterest, sticky-slink-tiktok, sticky-slink-whatsapp, sticky-slink-messenger, sticky-slink-telegram, sticky-slink-wechat, sticky-slink-viber, sticky-slinkeemail, sticky-slink-dribbble, sticky-slink-reddit, sticky-slink-snapchat, sticky-slink-medium, sticky-slink-quora, sticky-slink-tumblr">
                            <input type="submit" value="Save Changes">
                        </form>
                    </div>
                    <div id="social-style">
                        <form action="options.php" method="POST">
                            <?php wp_nonce_field('update-options'); ?>
                            
                            <p class="sslink-postion-p"><?php esc_html_e('Social Link Position', 'sticky-social-link'); ?></p>
                            <small><?php esc_html_e('Default: Right', 'sticky-social-link'); ?></small>
                            <div class="sslink-right">
                                <input type="radio" name="sslink-position" id="sslink-rightposition" value="right" <?php if(get_option('sslink-position') == 'right'){echo esc_attr('checked="checked"');} ?> >
                                <label for="sslink-rightposition"><?php esc_html_e('Right', 'sticky-social-link'); ?></label>
                            </div>
                            <div class="sslink-left">
                                <input type="radio" name="sslink-position" id="sslink-leftposition" value="left" <?php if(get_option('sslink-position') == 'left'){echo esc_attr('checked="checked"');} ?>>
                                <label for="sslink-leftposition"><?php esc_html_e('Left', 'sticky-social-link'); ?></label>
                            </div>
                            <div class="sslink-bottom">
                                <input type="radio" name="sslink-position" id="sslink-bottomposition" value="bottom" <?php if(get_option('sslink-position') == 'bottom'){echo esc_attr('checked="checked"');} ?>>
                                <label for="sslink-bottomposition"><?php esc_html_e('Bottom', 'sticky-social-link'); ?></label>
                            </div>
                            <label for="sslink-menubgcolor" style="margin-bottom:0;"><?php esc_html_e('Icons Menu Background Color', 'sticky-social-link'); ?></label>
                            <small><?php esc_html_e('Default: #000000', 'sticky-social-link'); ?></small>
                            <input type="color" name="sslink-menubgcolor" id="sslink-menubgcolor" value="<?php esc_url(print get_option('sslink-menubgcolor')); ?>">
                            <label for="sslink-iconbgcolor" style="margin-bottom:0;"><?php esc_html_e('Icons Background Color', 'sticky-social-link'); ?></label>
                            <small><?php esc_html_e('Default: #000000', 'sticky-social-link'); ?></small>
                            <input type="color" name="sslink-iconbgcolor" id="sslink-iconbgcolor" value="<?php esc_url(print get_option('sslink-iconbgcolor')); ?>">
                            <label for="sslink-iconhovercolor" style="margin-bottom:0;"><?php esc_html_e('Icons Hover Color', 'sticky-social-link'); ?></label>
                            <small><?php esc_html_e('Default: #000000', 'sticky-social-link'); ?></small>
                            <input type="color" name="sslink-iconhovercolor" id="sslink-iconhovercolor" value="<?php esc_url(print get_option('sslink-iconhovercolor')); ?>">
                            
                            <label for="sslink-roundcorner" style="margin-bottom:0;"><?php esc_html_e('Icons Round or Corner Style', 'sticky-social-link'); ?></label>
                            <small><?php esc_html_e('Default: Round', 'sticky-social-link'); ?></small>
                            <select name="sslink-roundcorner" id="sslink-roundcorner">
                                <option value="round" <?php if(get_option('sslink-roundcorner') == 'round'){echo esc_attr('selected="selected"');} ?> ><?php esc_html_e('Round', 'sticky-social-link'); ?></option>
                                <option value="corner" <?php if(get_option('sslink-roundcorner') == 'corner'){echo esc_attr('selected="selected"');} ?> ><?php esc_html_e('Corner', 'sticky-social-link'); ?></option>
                            </select>

                            <input type="hidden" name="action" value="update">
                            <input type="hidden" name="page_options" value="sslink-position, sslink-menubgcolor, sslink-iconbgcolor, sslink-iconhovercolor, sslink-roundcorner">
                            <input type="submit" value="Save Changes">
                        </form>
                    </div>
                </div>
            </div>
            <!-- Author Details -->
            <div class="sslink-author">
                <div class="sslink-title">
                    <h2><?php esc_html_e('Author', 'sticky-social-link'); ?></h2>
                </div>
                <div class="author-img">
                    <img src="<?php echo esc_url(SSLINK_PLUGIN_URL . 'img/habibcoder.jpg'); ?>" alt="HabibCoder">
                </div>
                <h4 class="author-name"> <?php esc_html_e('HabibCoder', 'sticky-social-link'); ?> </h4>
                <div class="author-description">
                    <p><?php esc_html_e('I\'m ', 'sticky-social-link'); ?><a href="<?php echo esc_url('http://habibcoder.com'); ?>" target="_blank"><?php esc_html_e('Habibur Rahman', 'sticky-social-link') ?></a> <?php esc_html_e('and a Professional Web Developer and Web Designer. For the last some years, I\'m working in this field with national and international clients. I have done many more projects with client satisfaction.', 'sticky-social-link'); ?><br>
                    <?php esc_html_e('This is an open-source WordPress Plugin. If you want to support me, You can', 'sticky-social-link'); ?> <b><?php esc_html_e('click on the Buy Me a Coffe Button', 'sticky-social-link'); ?></b>. <br> <?php esc_html_e('Thank You !.', 'sticky-social-link'); ?> </p>
                </div>
                <div class="donate-btn">
                    <a href="<?php echo esc_url('https://www.buymeacoffee.com/habibcoder'); ?>" target="_blank">
                    <h4><span>🍦</span><?php esc_html_e('Buy Me A Coffee', 'sticky-social-link'); ?></h4>
                    </a>
                </div>
                <h3 class="social-title"> 
                    <?php esc_html_e('Follow Me', 'sticky-social-link'); ?>
                </h3>
                <div class="social-icons">
                    <a class="facebook" title="Facebook" href="<?php echo esc_url('http://facebook.com/habibcoder1'); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL . 'img/sslink-facebook.png'); ?>" alt="facebook"></a>
                    <a class="linkedin" title="LinkedIn" href="<?php echo esc_url('http://linkedin.com/in/habibcoder'); ?>" target="_blank"><img src="<?php echo esc_url(SSLINK_PLUGIN_URL . 'img/sslink-linkedin.png'); ?>" alt="LinkedIn"></a>
                    <a class="instagram" title="Instagram" href="<?php echo esc_url('http://instagram.com/habibcoder'); ?>" target="_blank"><img src="<?php echo esc_url(SSLINK_PLUGIN_URL . 'img/sslink-instagram.png'); ?>" alt="instagram"></a>
                    <a class="website" title="Website" href="<?php echo esc_url('http://habibcoder.com'); ?>" target="_blank"><img src="<?php echo esc_url(SSLINK_PLUGIN_URL . 'img/website.png'); ?>" alt="HabibCoder"></a>
                </div>
                <div class="thank-you">
                    <span>♥</span>
                    <h5><?php esc_html_e('Thank You', 'sticky-social-link'); ?></h5>
                    <span>♥</span>
                </div>
            </div>
        </div>
    </div>

<?php
}