<?php  
/**
 * @package Sticky Social Link
 * 
 * Sticky Social Link Frontend Details
 */

 // ABSPATH Defined
if(!defined('ABSPATH')){
	exit('not valid');
}


/* ==========================
	Social Icons
========================== */
add_action('wp_footer', 'sslink_social_links_add');
function sslink_social_links_add(){ ?>
   
    <div class="sslink-socials">
        <ul class="sslink-menu">
            <?php if(!empty(get_option('sticky-slink-fb'))) : ?>
            <li class="facebook"><a title="Facebook" href="<?php esc_url(print get_option('sticky-slink-fb')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-facebook.png'); ?>" alt="facebook"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sticky-slink-twitter'))) : ?>
            <li class="twitter"><a title="Twitter" href="<?php esc_url(print get_option('sticky-slink-twitter')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-twitter.png'); ?>" alt="twitter"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sticky-slink-insta'))) : ?>
            <li class="instagram"><a title="Instagram" href="<?php esc_url(print get_option('sticky-slink-insta')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-instagram.png'); ?>" alt="instagram"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sticky-slink-linkedin'))) : ?>
            <li class="linkedin"><a title="LinkedIn" href="<?php esc_url(print get_option('sticky-slink-linkedin')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-linkedin.png'); ?>" alt="linkedin"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sticky-slink-youtube'))) : ?>
            <li class="youtube"><a title="YouTube" href="<?php esc_url(print get_option('sticky-slink-youtube')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-youtube.png'); ?>" alt="youtube"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sticky-slink-behance'))) : ?>
            <li class="behance"><a title="Behance" href="<?php esc_url(print get_option('sticky-slink-behance')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-behance.png'); ?>" alt="behance"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sticky-slink-pinterest'))) : ?>
            <li class="pinterest"><a title="Pinterest" href="<?php esc_url(print get_option('sticky-slink-pinterest')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-pinterest.png'); ?>" alt="pinterest"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sticky-slink-tiktok'))) : ?>
            <li class="tiktok"><a title="TikTok" href="<?php esc_url(print get_option('sticky-slink-tiktok')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-tiktok.png'); ?>" alt="tiktok"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sticky-slink-whatsapp'))) : ?>
            <li class="whatsapp"><a title="WhatsApp" href="https://web.whatsapp.com/send?phone=<?php esc_url(print get_option('sticky-slink-whatsapp')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-whatsapp.png'); ?>" alt="whatsapp"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sticky-slink-messenger'))) : ?>
            <li class="messenger"><a title="Messenger" href="http://m.me/<?php esc_url(print get_option('sticky-slink-messenger')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-messenger.png'); ?>" alt="messenger"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sticky-slink-telegram'))) : ?>
            <li class="telegram"><a title="Telegram" href="https://t.me/<?php esc_url(print get_option('sticky-slink-telegram')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-telegram.png'); ?>" alt="telegram"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sticky-slink-wechat'))) : ?>
            <li class="wechat"><a title="WeChat" href="<?php esc_url(print get_option('sticky-slink-wechat')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-wechat.png'); ?>" alt="wechat"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sticky-slink-viber'))) : ?>
            <li class="viber"><a title="Viber" href="viber://pa?chatURI=<?php esc_url(print get_option('sticky-slink-viber')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-viber.png'); ?>" alt="viber"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sticky-slinkeemail'))) : ?>
            <li class="email"><a title="Email" href="mailto:<?php esc_url(print get_option('sticky-slinkeemail')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-email.png'); ?>" alt="email"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sticky-slink-dribbble'))) : ?>
            <li class="dribbble"><a title="Dribbble" href="<?php esc_url(print get_option('sticky-slink-dribbble')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-dribbble.png'); ?>" alt="dribbble"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sticky-slink-reddit'))) : ?>
            <li class="reddit"><a title="Reddit" href="<?php esc_url(print get_option('sticky-slink-reddit')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-reddit.png'); ?>" alt="reddit"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sticky-slink-snapchat'))) : ?>
            <li class="snapchat"><a title="Snapchat" href="<?php esc_url(print get_option('sticky-slink-snapchat')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-snapchat.png'); ?>" alt="snapchat"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sticky-slink-medium'))) : ?>
            <li class="medium"><a title="Medium" href="<?php esc_url(print get_option('sticky-slink-medium')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-medium.png'); ?>" alt="medium"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sticky-slink-quora'))) : ?>
            <li class="quora"><a title="Quora" href="<?php esc_url(print get_option('sticky-slink-quora')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-quora.png'); ?>" alt="quora"></a></li>
            <?php endif; ?>
            <?php if(!empty(get_option('sticky-slink-tumblr'))) : ?>
            <li class="tumblr"><a title="Tumblr" href="<?php esc_url(print get_option('sticky-slink-tumblr')); ?>" target="_blank"><img src="<?php echo esc_url( SSLINK_PLUGIN_URL .'img/sslink-tumblr.png'); ?>" alt="tumblr"></a></li>
            <?php endif; ?>
        </ul>
    </div>

<?php
}