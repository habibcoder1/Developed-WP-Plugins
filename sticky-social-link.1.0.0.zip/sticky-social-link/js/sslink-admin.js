;(function($){
    'use strict';
    jQuery(document).ready(function(){

        jQuery('.sslink-tabs').tabs();

    });
})(jQuery);