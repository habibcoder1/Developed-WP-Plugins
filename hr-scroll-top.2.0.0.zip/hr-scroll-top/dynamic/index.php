<?php  
// Silence is gold