<?php  
/**
 * @package HR Scroll Top
 * 
 * HR Scroll Top Plugin Dynamic CSS & JS 
 */

 if(!defined('ABSPATH')){
    exit();
 }

?>

<!-- ========================================
 HR Scroll Top Dynamic Style and JavaScript 
========================================== -->
<style>
    /* BG Color */
    .hrscroll-top a img{
        background: <?php echo get_option('hrstbgcolor'); ?> !important;
    }
    /* BG Hover Color */
    .hrscroll-top a img:hover{
        background: <?php echo get_option('hrsthover'); ?> !important;
    }
    /* Icon Corner/Round */
    .hrscroll-top a img{
        <?php if( get_option('hrsticon-roundcorner') == 'true') : ?>
            border-radius: 50% !important;
        <?php endif; ?>
    }
    /* Icon Position */
    .hrscroll-top a{
        <?php if( get_option('hrsticon-left-right') == 'true') : ?>
            left: 10px !important;
            right: auto !important;
        <?php endif; ?>
    }
</style>

<!-- HR Scroll Top Script -->
<script>
    // Scroll to top with smoth
    jQuery(document).ready(function () {
        jQuery('.hrscroll-top a img').on('click', function(){
            jQuery('body, html').animate({scrollTop: 0}, <?php echo get_option('hrstspeed'); ?> );

            return false;
        });
    });
    
</script>

