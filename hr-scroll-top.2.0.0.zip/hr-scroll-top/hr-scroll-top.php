<?php 
/*
	Plugin Name:       HR Scroll Top
	Plugin URI:        https://habibcoder.com/hrscrolltop
	Author:            HabibCoder
	Author URI:        https://habibcoder.com
	License:           GNU General Public License
	License URI:       http://www.gnu.org/licenses/gpl-2.0.html
	Version:           2.0.0
	Requires at least: 5.0
	Tested up to:      6.1.1
	Requires PHP:      7.0
	Description:       HR Scroll Top is a very useful Scroll To Top plugin. This plugin has more icons, icon background color, icon color, Icon position and smooth scroll speed options. You can customize the HR Scroll Top Plugin as your wish. "HR Scroll Top" is easy to use.
	Tags: HR Scroll Top, scroll to top, popular plugin, hrscrolltop, hr scroll to top, hr scroll top, scroll to top, scroll top, scrolltop, Back Top, Back To Top, back to top
	Text Domain:       hrscrolltop
*/

// ABSPATH Defined
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/* ==============================
	Requires Files
============================== */
// admin option
if(file_exists( plugin_dir_path(__FILE__).'/admin/hrst_admin_option.php' )){
	require_once( plugin_dir_path(__FILE__).'/admin/hrst_admin_option.php' );
};


/* ==============================
	Style and Scropts Enqueue
============================== */
add_action('wp_enqueue_scripts', 'hr_scrolltop_stylejs');
function hr_scrolltop_stylejs(){
	// custom css
	wp_enqueue_style('hrst_style', PLUGINS_URL('css/hrst-style.css', __FILE__), array(), '2.0.0', 'all');
	// main js
	wp_enqueue_script('hrst_main', PLUGINS_URL('js/hrst-main.js', __FILE__), array('jquery'), '2.0.0', false);
};

/* ==============================
	Admin Stylesheet Enqueue
============================== */
add_action('admin_enqueue_scripts', 'hrst_admin_stylejs');
function hrst_admin_stylejs(){
	// admin style
	wp_enqueue_style( 'hrst-admin-style', PLUGINS_URL('css/hrst-admin-style.css', __FILE__), array(), '2.0.0', 'all'); 
};


/* ==============================
   Scroll Top Icons
============================== */
add_action('wp_footer', 'hr_scroll_top_function');
function hr_scroll_top_function(){

	// wp_footer contents/all icons load from dynamic/hrst_icons_load.php
	if(file_exists( plugin_dir_path(__FILE__).'/dynamic/hrst_icons_load.php' )){
		require_once( plugin_dir_path(__FILE__).'/dynamic/hrst_icons_load.php' );
	};
	
};



/* ==============================
   All Styles/JS Dynamic
============================== */
add_action('wp_head', 'hrst_dynamic_stylejs');
function hrst_dynamic_stylejs(){ 

	// wp_head content will load from dynamic/hrst_cssjs_dynamic.php file
	if(file_exists( plugin_dir_path(__FILE__).'/dynamic/hrst_cssjs_dynamic.php' )){
		require_once( plugin_dir_path(__FILE__).'/dynamic/hrst_cssjs_dynamic.php' );
	}

};



/* ===============================================
	Redirect Plugin Admin Page after Activate
=============================================== */
register_activation_hook( __FILE__, 'hrst_plugin_activation' );
function hrst_plugin_activation(){
	add_option( 'hrst_plugin_do_activated', true);
}

add_action( 'admin_init', 'hrst_plugin_redirect' );
function hrst_plugin_redirect(){
	if ( is_admin() && get_option('hrst_plugin_do_activated', false)) {
		delete_option( 'hrst_plugin_do_activated' );
		
		if(!isset($_GET['active_multi'])) {
			wp_safe_redirect( admin_url('admin.php?page=hrst-scroll-top') );
			exit;
		}

	}
};


