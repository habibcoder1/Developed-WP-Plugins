<?php  
/**
 *  @package HR Scroll Top
 * 
 *  HR Scroll Top Plugin Option
 */

 if(!defined('ABSPATH')){
   exit();
 }

//  Admin Menu
 add_action('admin_menu', 'hrst_admin_option');
 function hrst_admin_option(){

    add_menu_page( 'HR Scroll Top Options', __('HR Scroll Top', 'hrscrolltop'), 'manage_options', 'hrst-scroll-top', 'hrst_plugin_option', plugins_url().'/hr-scroll-top/img/admin-top.png', 65 );

 }

 function hrst_plugin_option(){  ?>
   
   <div class="hrst-option">
      <!-- HR Scroll Top Option Form -->
      <div class="hrst-option-form">
         <h2 class="hrst-admin-title"> 
            <?php _e('HR Scroll Top Option', 'hrscrolltop'); ?>
         </h2>
         <form action="options.php" method="POST">
         <?php wp_nonce_field('update-options');  // wp security ?> 
            <!-- Icon Images -->
            <label for="hrsticons"><?php _e('Which Icon you want to show?', 'hrscrolltop') ?></label>
            <small class="img-small"><?php _e('Click on your chosen icon & Save (Default Not Set)', 'hrscrolltop'); ?></small>
            <label for="hrsticon1" class="hrsticon">
               <img src="<?php echo plugins_url().'/hr-scroll-top/img/top.png'; ?>" alt="HR Scroll To Top Icon">
               <input type="radio" name="hrsticoninsert" id="hrsticon1" style="display: none;" value="hrsticon1" <?php if( get_option('hrsticoninsert') == 'hrsticon1' ){ echo 'checked="checked"'; } ?> >
            </label>
            <label for="hrsticon2" class="hrsticon">
               <img src="<?php echo plugins_url().'/hr-scroll-top/img/top1.png'; ?>" alt="HR Scroll To Top Icon">
               <input type="radio" name="hrsticoninsert" id="hrsticon2" style="display: none;" value="hrsticon2" <?php if( get_option('hrsticoninsert') == 'hrsticon2' ){ echo 'checked="checked"'; } ?> >
            </label>
            <label for="hrsticon3" class="hrsticon">
               <img src="<?php echo plugins_url().'/hr-scroll-top/img/top2.png'; ?>" alt="HR Scroll To Top Icon">
               <input type="radio" name="hrsticoninsert" id="hrsticon3" style="display: none;" value="hrsticon3" <?php if( get_option('hrsticoninsert') == 'hrsticon3' ){ echo 'checked="checked"'; } ?> >
            </label>
            <label for="hrsticon4" class="hrsticon">
               <img src="<?php echo plugins_url().'/hr-scroll-top/img/top3.png'; ?>" alt="HR Scroll To Top Icon">
               <input type="radio" name="hrsticoninsert" id="hrsticon4" style="display: none;" value="hrsticon4" <?php if( get_option('hrsticoninsert') == 'hrsticon4' ){ echo 'checked="checked"'; } ?> >
            </label>
            <label for="hrsticon5" class="hrsticon">
               <img src="<?php echo plugins_url().'/hr-scroll-top/img/top4.png'; ?>" alt="HR Scroll To Top Icon">
               <input type="radio" name="hrsticoninsert" id="hrsticon5" style="display: none;" value="hrsticon5" <?php if( get_option('hrsticoninsert') == 'hrsticon5' ){ echo 'checked="checked"'; } ?> >
            </label>
            <label for="hrsticon6" class="hrsticon">
               <img src="<?php echo plugins_url().'/hr-scroll-top/img/top5.png'; ?>" alt="HR Scroll To Top Icon">
               <input type="radio" name="hrsticoninsert" id="hrsticon6" style="display: none;" value="hrsticon6" <?php if( get_option('hrsticoninsert') == 'hrsticon6' ){ echo 'checked="checked"'; } ?> >
            </label>

            <!-- BG Color -->
            <label for="hrstbgcolor"><?php _e('Icon Background Color', 'hrscrolltop'); ?></label>
            <small><?php _e('Default: #000000', 'hrscrolltop'); ?></small>
            <input type="color" name="hrstbgcolor" id="hrstbgcolor" value="<?php echo get_option('hrstbgcolor'); ?>">

            <!-- Hover Color -->
            <label for="hrsthover"><?php _e('Icon Hover Color', 'hrscrolltop'); ?></label>
            <small><?php _e('Default: #000000', 'hrscrolltop'); ?></small>
            <input type="color" name="hrsthover" id="hrsthover" value="<?php echo get_option('hrsthover'); ?>">

            <!-- Icon Left -->
            <p style="margin-bottom: 0"><?php _e('Where you want to show icon?', 'hrscrolltop'); ?></p>
            <small><?php _e('Default has Right side', 'hrscrolltop'); ?></small>
            <p class="icon-left">
               <input type="radio" name="hrsticon-left-right" id="hrsticon-left-right" value="true" <?php if( get_option('hrsticon-left-right') == 'true' ){ echo 'checked="checked"'; } ?> >
               <label for="hrsticon-left-right" class="icon-left"><?php _e('Icon Left', 'hrscrolltop'); ?></label>
            </p>
            <!-- Icon Right -->
            <p class="icon-right">
               <input type="radio" name="hrsticon-left-right" id="hrsticon-left-right1" value="false" <?php if( get_option('hrsticon-left-right') == 'false' ){ echo 'checked="checked"'; } ?> >
               <label for="hrsticon-left-right1" class="icon-right"><?php _e('Icon Right', 'hrscrolltop'); ?></label>
            </p>

            <!-- Icon Round/Corner -->
            <label for="hrsticon-roundcorner"><?php _e('Icon Round or Corner', 'hrscrolltop'); ?></label>
            <small><?php _e('Default has Corner', 'hrscrolltop'); ?></small>
            <select name="hrsticon-roundcorner" id="hrsticon-roundcorner">
               <option value="false" <?php if(get_option('hrsticon-roundcorner') == 'false') {
                 echo 'selected="selected"'; } ?> > Corner </option>
               <option value="true" <?php if(get_option('hrsticon-roundcorner') == 'true') { echo 'selected="selected"'; } ?> > Round </option>
            </select>

            <!-- Scroll Speed -->
            <label for="hrstspeed"><?php _e('Scroll Speed', 'hrscrolltop'); ?></label>
            <small><?php _e('Range is 100 to 1200 (more value takes more time to scroll). Default 650', 'hrscrolltop'); ?></small>
            <input type="range" name="hrstspeed" id="hrstspeed" min="100" max="1200" value="<?php echo get_option('hrstspeed'); ?>" >

            <input type="hidden" name="action" value="update">
            <input type="hidden" name="page_options" value="hrsticoninsert, hrstbgcolor, hrsthover, hrsticon-left-right, hrsticon-roundcorner, hrstspeed">
            <input type="submit" value="<?php _e('Save Changes', 'hrscrolltop'); ?>">
         </form>
      </div>
      <!-- Author Details -->
      <div class="hrst-author">
         <h2 class="hrst-author-title"> 
            <?php _e('Author', 'hrscrolltop'); ?>
         </h2>
         <div class="author-img">
            <img src="<?php echo plugins_url().'/hr-scroll-top/img/habibcoder.jpg' ?>" alt="HabibCoder">
         </div>
         <h4 class="author-name"> Habibur Rahman </h4>
         <div class="author-description">
            <p>I'm <a href="http://habibcoder.com" target="_blank">Habibur Rahman</a> and a Professional Web Developer and Web Designer. For the last some years, I'm working in this field with national and international clients. I have done many more projects with client satisfaction. <br>
            This is an open-source WordPress Plugin. If you want to support me, You can <b>click on the Buy Me a Coffe Button</b>. <br> Thank You !. </p>
         </div>
         <div class="donate-btn">
            <a href="https://www.buymeacoffee.com/habibcoder" target="_blank">
               <h4><span>🍦</span>Buy Me A Coffee</h4>
            </a>
         </div>
         <h3 class="hrst-social-title"> 
            <?php _e('Follow Me', 'hrscrolltop'); ?>
         </h3>
         <div class="social-icons">
            <a class="facebook" title="Facebook" href="http://facebook.com/habibcoder1" target="_blank"><img src="<?php echo plugins_url().'/hr-scroll-top/img/facebook.png' ?>" alt="facebook"></a>
            <a class="linkedin" title="LinkedIn" href="http://linkedin.com/in/habibcoder" target="_blank"><img src="<?php echo plugins_url().'/hr-scroll-top/img/linkedin.png' ?>" alt="LinkedIn"></a>
            <a class="instagram" title="Instagram" href="http://instagram.com/habibcoder" target="_blank"><img src="<?php echo plugins_url().'/hr-scroll-top/img/instagram.png' ?>" alt="instagram"></a>
            <a class="website" title="Website" href="http://habibcoder.com" target="_blank"><img src="<?php echo plugins_url().'/hr-scroll-top/img/website.png' ?>" alt="HabibCoder"></a>
         </div>
         <div class="thank-you">
            <span>♥</span>
            <h5>Thank You</h5>
            <span>♥</span>
         </div>
      </div>
      <!-- Script for selected image color -->
      <script>
         jQuery(document).ready(function () {
            let checked = jQuery('.hrst-option input:radio[checked="checked"]').parent('label');
            let checkimg = checked.find('img');
            checkimg.css('background-color', '#ccc');
         }); 
      </script>
      
   </div>

<?php
 }

