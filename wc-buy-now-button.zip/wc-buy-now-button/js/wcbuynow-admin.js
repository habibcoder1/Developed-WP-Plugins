;(function($){
    'use strict';
    jQuery(document).ready(function(){
        // jQuery Tabs
        jQuery('.wcbuynow-tabs').tabs();

    });
}(jQuery));