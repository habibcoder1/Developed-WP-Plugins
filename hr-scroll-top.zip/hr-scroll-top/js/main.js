(function($){
	'use strict';
	jQuery(document).ready(function(){
		
		// Hide and Show
		jQuery('.scroll-top a').hide();
		jQuery(window).scroll(function(){
			if (jQuery(window).scrollTop() > 300) {
				jQuery('.scroll-top a').fadeIn();
			}else{
				jQuery('.scroll-top a').fadeOut();
			}
		});
		// Scroll to top with smoth
		jQuery('.scroll-top a i').on('click', function(){
			jQuery('body, html').animate({scrollTop: 0}, 1000);

			return false;
		});

	});
})(jQuery)