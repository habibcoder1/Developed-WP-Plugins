=== HR Scroll Top ===
Contributor: hrhabibpro
Donate link: https:habibcoder.com
Tags: scroll to top, popular plugin, hrscrolltop, hr scroll to top, hr scroll top, scroll to top, scroll top, scrolltop
Requires at least: 5.0
Tested up to: 5.9
Stable tag: 1.0.2
Requires PHP: 7.0
License: GNU General Public License
License URI: http://www.gnu.org/licenses/gpl-2.0.html

HR Scroll Top Plugin is very usefull scroll to top plugin. Everybody can use this plugin in their websites.

== Description ==

HR Scroll Top Plugin is very usefull scroll to top plugin. Everybody can use this plugin in their websites. HR Scroll Top is easy to use.

== Frequently Asked Questions ==

= May I use this plugin in any websites? =

Yes.

= Is it very hard to install and use? =

No, It is very easy to install and use.

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Screenshots are stored in the /assets directory.
2. This is the second screen shot

== Changelog ==

= 1.0.2 =
* A new plugin

== Upgrade Notice ==



Links require brackets and parenthesis:

Here's a link to [WordPress](https://wordpress.org/ "Your favorite software") and one to [Markdown's Syntax Documentation][markdown syntax]. Link titles are optional, naturally.

Blockquotes are email style:

> Asterisks for *emphasis*. Double it up  for **strong**.

And Backticks for code:

`<?php code(); ?>`