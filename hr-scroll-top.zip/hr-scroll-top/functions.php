<?php 
/*
	Plugin Name: HR Scroll Top 
	Plugin URI: https://websiteslearn.com
	Author: HR Habib
	Author URI: https://habibcoder.com
	Version: 1.0.2
	Description: This is a Popular and Simple Scroll To Top plugin, We can use this plugin on any website for adding Scroll To Top option.
	Tags: scroll to top, popular plugin, hrscrolltop, hr scroll to top, hr scroll top, scroll to top, scroll top, scrolltop
	License: GNU General Public License
	License URI: http://www.gnu.org/licenses/gpl-2.0.html
	Text Domain: hrscrolltop
	Requires at least: 5.0
	Tested up to: 5.9
	Requires PHP: 7.0
*/

// ABSPATH Defined
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


// style connect
add_action('wp_enqueue_scripts', 'hr_scrolltop_styles');
function hr_scrolltop_styles(){
	// font-awesome
	wp_enqueue_style('hr_font-awesome-all', PLUGINS_URL('css/all.min.css', __FILE__));
	wp_enqueue_style('hr_font-awesome', PLUGINS_URL( 'css/fontawesome.min-6.1.1.css', __FILE__ ));
	// custom css
	wp_enqueue_style('hr_custom_css', PLUGINS_URL('css/custom.css', __FILE__));
}

// scripts connect
add_action('wp_enqueue_scripts', 'hr_scrolltop_scritps');
function hr_scrolltop_scritps(){
	// main js
	wp_enqueue_script('hr_main', PLUGINS_URL('js/main.js', __FILE__), array('jquery'), ' ', false);
}

// scroll top icon
add_action('wp_footer', 'hr_scroll_top_function');
function hr_scroll_top_function(){
	?>
		<div class="scroll-top">
			<a href="#" title="Go Up"><i class="fa-solid fa-angle-up"></i></a>
		</div>

	<?php
}

