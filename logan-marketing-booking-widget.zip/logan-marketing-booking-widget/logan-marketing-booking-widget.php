<?php 
/* ============================
Plugin Name: Logan Marketing Booking Widget
Plugin URI: https://backbencher.studio/
Author: Logan Marketing Booking Widget
Author URI: https://backbencher.studio/
Version: 1.1.0
Required at least: 6.0
Test up to: 6.4.3
Required PHP: 7.0
Tags: booking, logan booking widget, booking widget, booking, logan marketing, logan marketing booking widget
Description: Logan Marketing Booking Widget is an Elementor addon to help to make the search functionality with an external link
Text Domain: jeffsearchwidget
============================ */


// ABSPATH Defined
if (!defined('ABSPATH')) { 
	exit('not valid');
}


// Check if Elementor is active
if (in_array('elementor/elementor.php', get_option('active_plugins'))) {
    // Elementor is active
    

	// Register Widget //
	function jeff_search_elementor_widget( $widgets_manager ) {

		require_once( __DIR__ . '/main/jeff-search-widget-details.php' );

		$widgets_manager->register( new \Jeff_Search_Elementor_Addon_Dev() );

	}
	add_action( 'elementor/widgets/register', 'jeff_search_elementor_widget' );


	// Enqueues All //
	function jeff_search_widget_enqueue_all() {
		// javascript
		wp_register_script('jeff-search-widget-script', plugins_url('js/jeff-search-widget.js', __FILE__), array('jquery'), '1.0.0', true);
		// stylesheet
		wp_register_style('jeff-search-widget-style', plugins_url('css/jeff-search-widget.css', __FILE__), array(), '1.0.0', 'all');
		// font awesome
		wp_enqueue_style( 'jeff-search-widget-font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css' );
	}
	add_action('elementor/frontend/after_register_scripts', 'jeff_search_widget_enqueue_all');


	// Register New Category //
	function jeff_search_widget_new_category( $elements_manager ) {
		$elements_manager->add_category( 'jeffsearchwidget-category', [
				'title' => esc_html__( 'Booking Widget', 'jeffsearchwidget' ),
				'icon'  => 'fa fa-plug', 
			]
		);
	}
	add_action( 'elementor/elements/categories_registered', 'jeff_search_widget_new_category' );




}else{
    // Elementor is not active
    add_action('admin_notices', 'jeff_search_widget_missing_notice');
    function jeff_search_widget_missing_notice() {
        $message = 'This Plugin requires Elementor. Please activate Elementor to use this plugin.';
        echo '<div class="notice notice-error is-dismissible"><p>' . $message . '</p></div>';

        deactivate_plugins(plugin_basename(__FILE__));  //not active
    }

} // endif for if elementor activated


