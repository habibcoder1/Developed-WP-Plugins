<?php  
/**
 * @package Jeff Booking Widget
 * 
 * elementor jeff booking widget details
 */

// ABSPATH Defined
if (!defined('ABSPATH')) {
	exit('not valid');
}


class Jeff_Search_Elementor_Addon_Dev extends \Elementor\Widget_Base {
	// any name here. it will be used in code
	public function get_name() {
		return 'jeffsearchwidget-one';
	}
	// widget title
	public function get_title() {
		return esc_html__( 'Booking Widget', 'jeffsearchwidget' );
	}
	// elementor icons & fontawesome icons allow here
	public function get_icon() {
		return 'eicon-search-results';
	}
	// user can know more from this link (need help link)
	public function get_custom_help_url() {
		return 'https://backbencher.studio';
	}
	// for category
	public function get_categories() {
		return [ 'jeffsearchwidget-category' ];  //developed category
	}
	// keywords for filter/search the widget list
	public function get_keywords() {
		return [ 'search', 'search widget', 'jeff search', 'jeff search widget' ];
	}
	// for scripts load
	public function get_script_depends() {
		return ['jeff-search-widget-script']; //array key from enqueue script
	}
	// for stylesheet load
	public function get_style_depends() {
		return ['jeff-search-widget-style']; //array key from enqueue style
	}
	// for backend control ///////////
    protected function register_controls() {
		/* =======================
			 for content tab 
		======================= */
		// start controls
		$this->start_controls_section(
			'jeffcontent_section',  //any text here (id)
			[
				'label' => esc_html__( 'All Content', 'jeffsearchwidget' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,   //content tab
			]
		);

		// select date content
		$this->add_control(
			'jeff_selectdate_content',  //any text here (id)
			[
				'type' 		  => \Elementor\Controls_Manager::TEXT,  //text
				'label'		  => __( 'Select Date content <br><span style="opacity:.6;">(leave empty for hide)</span>', 'jeffsearchwidget' ),
				'placeholder' => esc_html__( 'Select Date', 'jeffsearchwidget' ),
				'label_block' => true,
				'default'     => 'Select Date',
				'dynamic'     => [
					'active'  => true,  //for dynamic tag option
				],
			]
		);	

		// Search Availability content
		$this->add_control(
			'jeff_searchavailability_content',  //any text here (id)
			[
				'type' 		  => \Elementor\Controls_Manager::TEXT,  //text
				'label'		  => esc_html__( 'Search Availability content', 'jeffsearchwidget' ),
				'placeholder' => esc_html__( 'Search Availability', 'jeffsearchwidget' ),
				'label_block' => true,
				'default'     => 'Search Availability',
				'dynamic'     => [
					'active'  => true,  //for dynamic tag option
				],
			]
		);		
		// redirect url
		$this->add_control(
			'jeff_redirect_url',  //any text here (id)
			[
				'type' 		  => \Elementor\Controls_Manager::URL,  //url
				'label'		  => esc_html__( 'Search Form Redirect URL', 'jeffsearchwidget' ),
				'placeholder' => esc_html__( 'Redirect URL', 'jeffsearchwidget' ),
				'options'     => [ 'url', 'is_external' ],
				'label_block' => true,
				'default'     => [
					'url'         => 'https://secure.thinkreservations.com/deepcreekinns/reservations/availability',
					'is_external' => false,
					'nofollow'    => false,
					// 'custom_attributes' => '',
				],
			]
		);		

		$this->end_controls_section(); //end content controls


		/* =======================
			for style tab
		======================= */
		// start controls
		$this->start_controls_section(
			'jeff_stylesheet',
			[
				'label' => __( 'All Style', 'jeffsearchwidget' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		// Search form width
		$this->add_responsive_control(
			'jeff_form_width',
			[
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'label'     => esc_html__( 'Search Form Width', 'jeffsearchwidget' ),
				'size_units' => [  '%', 'px', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		// form alignment
		$this->add_responsive_control(
			'jeff_searchform_alignment',
			[
				'type'        => \Elementor\Controls_Manager::CHOOSE,
				'label'       => esc_html__( 'Search Form Alignment', 'jeffsearchwidget' ),
				'label_block' => true,
				'options'     => [
					'left'    => [
						'title' => esc_html__( 'Left', 'jeffsearchwidget' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center'  => [
						'title' => esc_html__( 'Center', 'jeffsearchwidget' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'   => [
						'title' => esc_html__( 'Right', 'jeffsearchwidget' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'     => 'left',
				'selectors_dictionary' => [
					'center' => '{{VALUE}}' ? 'auto' : 'left',
					'right'  => '{{VALUE}}' ? '0 0 0 auto' : 'left',
				],
				'selectors' => [
					'{{WRAPPER}} .jeff_search_form_div form' => 'margin: {{VALUE}};',
				],			
				
				
			]
		);
		
		// form bg color
		$this->add_control(
			'jeff_formbg_color',
			[
				'label' => esc_html__( 'Form BG Color', 'jeffsearchwidget' ),
				'type'  => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform' => 'background-color: {{VALUE}};',
				],
			]
		);
		// form padding
		$this->add_responsive_control(
			'jeff_form_gap',
			[
				'label'      => esc_html__( 'Form Padding', 'jeffsearchwidget' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .jeffsearchform' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// form border
		$this->add_control(
			'jeff_form_border_style',
			[
				'type'      => \Elementor\Controls_Manager::SELECT,
				'label'     => esc_html__( 'Form Border Style', 'jeffsearchwidget' ),
				'options'   => [
					''       => esc_html__( 'None', 'jeffsearchwidget' ),
					'solid'  => esc_html__( 'Solid', 'jeffsearchwidget' ),
					'dashed' => esc_html__( 'Dashed', 'jeffsearchwidget' ),
					'dotted' => esc_html__( 'Dotted', 'jeffsearchwidget' ),
					'double' => esc_html__( 'Double', 'jeffsearchwidget' ),
				],
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform' => 'border-style: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'jeff_form_border_width',
			[
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'label'     => esc_html__( 'Form Border Width', 'jeffsearchwidget' ),
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'jeff_form_border_color',
			[
				'type'      => \Elementor\Controls_Manager::COLOR,
				'label'     => esc_html__( 'Form Border Color', 'jeffsearchwidget' ),
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform' => 'border-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'jeff_form_border_radius',
			[
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'label'     => esc_html__( 'Form Border Radius', 'jeffsearchwidget' ),
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Select Date option start //
		$this->add_control(
			'jeff_selectdate_options',
			[
				'label' => __('<b style="margin-top:8px; font-size:15px;display:block;">Select Date Text</b>', 'jeffsearchwidget' ),
				'type' => \Elementor\Controls_Manager::RAW_HTML,
			]
		);

		// select date color
		$this->add_control(
			'jeff_selectdate_color',
			[
				'label' => esc_html__( 'Select Date Text Color', 'jeffsearchwidget' ),
				'type'  => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform .selectdatalabel' => 'color: {{VALUE}};',
				],
			]
		);
		// jeff select date typography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' 		=> 'jeff_selectdate_typography',
				'label' 	=> esc_html__( 'Select Date Typography', 'jeffsearchwidget' ),
				'selector' 	=> '{{WRAPPER}} .jeffsearchform .selectdatalabel',
				'global' 	=> [
					'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Typography::TYPOGRAPHY_PRIMARY,
				],
			]
		);
		// check in date alignment
		$this->add_responsive_control(
			'jeff_selectdate_alignment',  //any text here (id)
			[
				'type'    => \Elementor\Controls_Manager::CHOOSE,  //choose option
				'label'   => esc_html__( 'Select Date Alignment', 'jeffsearchwidget' ),
				'label_block' => true,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'jeffsearchwidget' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'jeffsearchwidget' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'jeffsearchwidget' ),
						'icon'  => 'eicon-text-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justify', 'jeffsearchwidget' ),
						'icon'  => 'eicon-text-align-justify',
					],
				],
				'default'    => 'left',
				'selectors'  => [
					'{{WRAPPER}} .jeffsearchform .selectdatalabel' => 'text-align: {{VALUE}}; display: block;',
				],
			]
		);
		// select date content gap
		$this->add_responsive_control(
			'jeff_selectdate_content_gap',
			[
				'label'      => esc_html__( 'Select Date Content Gap', 'jeffsearchwidget' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .jeffsearchform .selectdatalabel' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Start Date option start //
		$this->add_control(
			'jeff_startdate_options',
			[
				'label' => __('<b style="margin-top:8px; font-size:15px;display:block;">Check In Date Options</b>', 'jeffsearchwidget' ),
				'type' => \Elementor\Controls_Manager::RAW_HTML,
			]
		);
		// start date width
		$this->add_responsive_control(
			'jeff_start_date_width',
			[
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'label'     => esc_html__( 'Date Width', 'jeffsearchwidget' ),
				'size_units' => [  '%', 'px', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform input#start_date' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		// start date date alignment
		$this->add_responsive_control(
			'jeff_start_date_alignment',  //any text here (id)
			[
				'type'    => \Elementor\Controls_Manager::CHOOSE,  //choose option
				'label'   => esc_html__( 'Check In Alignment', 'jeffsearchwidget' ),
				'label_block' => true,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'jeffsearchwidget' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'jeffsearchwidget' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'jeffsearchwidget' ),
						'icon'  => 'eicon-text-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justify', 'jeffsearchwidget' ),
						'icon'  => 'eicon-text-align-justify',
					],
				],
				'default'    => 'left',
				'selectors'  => [
					'{{WRAPPER}} .jeffsearchform input#start_date' => 'text-align: {{VALUE}};',
				],
			]
		);
		//check in typography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' 		=> 'jeff_checkin_date_typography',
				'label' 	=> esc_html__( 'Check In Typography', 'jeffsearchwidget' ),
				'selector' 	=> '{{WRAPPER}} .jeffsearchform input#start_date',
				'global' 	=> [
					'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Typography::TYPOGRAPHY_PRIMARY,
				],
			]
		);
		// start date color
		$this->add_control(
			'jeff_startdate_input_color',
			[
				'label' => esc_html__( 'Date Color', 'jeffsearchwidget' ),
				'type'  => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform input#start_date' => 'color: {{VALUE}};',
				],
			]
		);
		// start date bg color
		$this->add_control(
			'jeff_startdate_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'jeffsearchwidget' ),
				'type'  => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform input#start_date' => 'background-color: {{VALUE}};',
				],
			]
		);
		// start date border
		$this->add_control(
			'jeff_startdate_border_style',
			[
				'type'      => \Elementor\Controls_Manager::SELECT,
				'label'     => esc_html__( 'Border Style', 'jeffsearchwidget' ),
				'options'   => [
					''       => esc_html__( 'None', 'jeffsearchwidget' ),
					'solid'  => esc_html__( 'Solid', 'jeffsearchwidget' ),
					'dashed' => esc_html__( 'Dashed', 'jeffsearchwidget' ),
					'dotted' => esc_html__( 'Dotted', 'jeffsearchwidget' ),
					'double' => esc_html__( 'Double', 'jeffsearchwidget' ),
				],
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform input#start_date' => 'border-style: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'jeff_startdate_border_width',
			[
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'label'     => esc_html__( 'Border Width', 'jeffsearchwidget' ),
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform input#start_date' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'jeff_startdate_border_color',
			[
				'type'      => \Elementor\Controls_Manager::COLOR,
				'label'     => esc_html__( 'Border Color', 'jeffsearchwidget' ),
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform input#start_date' => 'border-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'jeff_start_date_border_radius',
			[
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'label'     => esc_html__( 'Border Radius', 'jeffsearchwidget' ),
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform input#start_date' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		// start date gap
		$this->add_responsive_control(
			'jeff_start_date_margin',
			[
				'label'      => esc_html__( 'Margin', 'jeffsearchwidget' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .jeffsearchform input#start_date' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'jeff_start_date_padding',
			[
				'label'      => esc_html__( 'Padding', 'jeffsearchwidget' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .jeffsearchform input#start_date' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// End Date option start //
		$this->add_control(
			'jeff_enddate_options',
			[
				'label' => __('<b style="margin-top:8px; font-size:15px;display:block;">Check Out Date Options</b>', 'jeffsearchwidget' ),
				'type' => \Elementor\Controls_Manager::RAW_HTML,
			]
		);
		// end date width
		$this->add_responsive_control( 
			'jeff_end_date_width', 
			[
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'label'     => esc_html__( 'Date Width', 'jeffsearchwidget' ),
				'size_units' => [  '%', 'px', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform input#end_date' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		// end date alignment
		$this->add_responsive_control(
			'jeff_end_date_alignment',  //any text here (id)
			[
				'type'    => \Elementor\Controls_Manager::CHOOSE,  //choose option
				'label'   => esc_html__( 'Check Out Alignment', 'jeffsearchwidget' ),
				'label_block' => true,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'jeffsearchwidget' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'jeffsearchwidget' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'jeffsearchwidget' ),
						'icon'  => 'eicon-text-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justify', 'jeffsearchwidget' ),
						'icon'  => 'eicon-text-align-justify',
					],
				],
				'default'    => 'left',
				'selectors'  => [
					'{{WRAPPER}} .jeffsearchform input#end_date' => 'text-align: {{VALUE}};',
				],
			]
		);
		//check out typography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' 		=> 'jeff_check_out_date_typography',
				'label' 	=> esc_html__( 'Check Out Typography', 'jeffsearchwidget' ),
				'selector' 	=> '{{WRAPPER}} .jeffsearchform input#end_date',
				'global' 	=> [
					'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Typography::TYPOGRAPHY_PRIMARY,
				],
			]
		);
		// end date color
		$this->add_control(
			'jeff_enddate_input_color',
			[
				'label' => esc_html__( 'Date Color', 'jeffsearchwidget' ),
				'type'  => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform input#end_date' => 'color: {{VALUE}};',
				],
			]
		);
		// end date bg color
		$this->add_control(
			'jeff_enddate_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'jeffsearchwidget' ),
				'type'  => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform input#end_date' => 'background-color: {{VALUE}};',
				],
			]
		);
		// end date border
		$this->add_control(
			'jeff_enddate_border_style',
			[
				'type'      => \Elementor\Controls_Manager::SELECT,
				'label'     => esc_html__( 'Border Style', 'jeffsearchwidget' ),
				'options'   => [
					''       => esc_html__( 'None', 'jeffsearchwidget' ),
					'solid'  => esc_html__( 'Solid', 'jeffsearchwidget' ),
					'dashed' => esc_html__( 'Dashed', 'jeffsearchwidget' ),
					'dotted' => esc_html__( 'Dotted', 'jeffsearchwidget' ),
					'double' => esc_html__( 'Double', 'jeffsearchwidget' ),
				],
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform input#end_date' => 'border-style: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'jeff_enddate_border_width',
			[
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'label'     => esc_html__( 'Border Width', 'jeffsearchwidget' ),
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform input#end_date' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'jeff_enddate_border_color',
			[
				'type'      => \Elementor\Controls_Manager::COLOR,
				'label'     => esc_html__( 'Border Color', 'jeffsearchwidget' ),
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform input#end_date' => 'border-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'jeff_end_date_border_radius',
			[
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'label'     => esc_html__( 'Border Radius', 'jeffsearchwidget' ),
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform input#end_date' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		// end date gap
		$this->add_responsive_control(
			'jeff_end_date_margin',
			[
				'label'      => esc_html__( 'Margin', 'jeffsearchwidget' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .jeffsearchform input#end_date' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'jeff_end_date_padding',
			[
				'label'      => esc_html__( 'Padding', 'jeffsearchwidget' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .jeffsearchform input#end_date' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		// search availability option start //
		$this->add_control(
			'jeff_searchavailability_notice',
			[
				'label' => __('<b style="margin-top:8px; font-size:15px;display:block;">Search Button Options</b>', 'jeffsearchwidget' ),
				'type' => \Elementor\Controls_Manager::RAW_HTML,
			]
		);
		// earch availability width
		$this->add_responsive_control(
			'jeff_search_availability_button_width',
			[
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'label'     => esc_html__( 'Search Button Width', 'jeffsearchwidget' ),
				'size_units' => [  '%', 'px', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform button' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		// search button alignment
		$this->add_responsive_control(
			'jeff_search_availability_button_alignment',  //any text here (id)
			[
				'type'    => \Elementor\Controls_Manager::CHOOSE,  //choose option
				'label'   => esc_html__( 'Search Button Alignment', 'jeffsearchwidget' ),
				'label_block' => true,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'jeffsearchwidget' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'jeffsearchwidget' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'jeffsearchwidget' ),
						'icon'  => 'eicon-text-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justify', 'jeffsearchwidget' ),
						'icon'  => 'eicon-text-align-justify',
					],
				],
				'default'    => 'left',
				'selectors'  => [
					'{{WRAPPER}} .jeffsearchform button' => 'text-align: {{VALUE}};',
				],
			]
		);
		// search availability color
		$this->add_control(
			'jeff_searchavailability_color',
			[
				'label' => esc_html__( 'Button Color', 'jeffsearchwidget' ),
				'type'  => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform button' => 'color: {{VALUE}};',
				],
			]
		);
		// search availability hover color
		$this->add_control(
			'jeff_searchavailabilityhover_color',
			[
				'label' => esc_html__( 'Button Hover Color', 'jeffsearchwidget' ),
				'type'  => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform button:hover' => 'color: {{VALUE}};',
				],
			]
		);
		// select date backgroun color
		$this->add_control(
			'jeff_searchavailability_bgcolor',
			[
				'label' => esc_html__( 'Background Color', 'jeffsearchwidget' ),
				'type'  => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform button' => 'background-color: {{VALUE}};',
				],
			]
		);
		// select date backgroun hover color
		$this->add_control(
			'jeff_searchavailability_bghovercolor',
			[
				'label' => esc_html__( 'Background Hover Color', 'jeffsearchwidget' ),
				'type'  => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform button:hover' => 'background-color: {{VALUE}};',
				],
			]
		);
		// select date typhography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' 		=> 'jeff_searchavailability_typography',
				'label' 	=> esc_html__( 'Typography', 'jeffsearchwidget' ),
				'selector' 	=> '{{WRAPPER}} .jeffsearchform button',
				'global' 	=> [
					'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Typography::TYPOGRAPHY_PRIMARY,
				],
			]
		);
		// search availability content gap
		$this->add_responsive_control(
			'jeff_searchavailability_content_margin',
			[
				'label'      => esc_html__( 'Margin', 'jeffsearchwidget' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .jeffsearchform button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'jeff_searchavailability_content_padding',
			[
				'label'      => esc_html__( 'Padding', 'jeffsearchwidget' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .jeffsearchform button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		// search availability border
		$this->add_control(
			'jeff_searchavailability_border_style',
			[
				'type'      => \Elementor\Controls_Manager::SELECT,
				'label'     => esc_html__( 'Border Style', 'jeffsearchwidget' ),
				'options'   => [
					' '       => esc_html__( 'None', 'jeffsearchwidget' ),
					'solid'  => esc_html__( 'Solid', 'jeffsearchwidget' ),
					'dashed' => esc_html__( 'Dashed', 'jeffsearchwidget' ),
					'dotted' => esc_html__( 'Dotted', 'jeffsearchwidget' ),
					'double' => esc_html__( 'Double', 'jeffsearchwidget' ),
				],
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform button' => 'border-style: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'jeff_searchavailability_border_width',
			[
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'label'     => esc_html__( 'Border Width', 'jeffsearchwidget' ),
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform button' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'jeff_searchavailability_border_color',
			[
				'type'      => \Elementor\Controls_Manager::COLOR,
				'label'     => esc_html__( 'Border Color', 'jeffsearchwidget' ),
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform button' => 'border-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'jeff_searchavailability_border_radius',
			[
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'label'     => esc_html__( 'Border Radius', 'jeffsearchwidget' ),
				'selectors' => [
					'{{WRAPPER}} .jeffsearchform button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		
		
		

		$this->end_controls_section(); //end style tab

    }  //end regsiter controls

	// for forntend ////////
	protected function render() { 

		$settings = $this->get_settings_for_display(); 

		$target   = $settings['jeff_redirect_url']['is_external'] ? 'target="_blank"' : '';
		$url      = $settings['jeff_redirect_url']['url'] ? $settings['jeff_redirect_url']['url'] : '';
		$nofollow = $settings['jeff_redirect_url']['nofollow'] ? 'rel="nofollow"' : '';

		if(!empty('jeff_selectdate_content')) : ?>

		<div class="jeff_search_form_div">

			<form class="jeffsearchform" action="<?php echo $url; ?>" method="GET" <?php echo $target; echo $nofollow; ?> >
				<label for="select_datecontent" class="selectdatalabel"><?php echo $settings['jeff_selectdate_content']; ?></label>
				<!-- check in -->
				<input type="date" id="start_date" name="start_date" value="<?php echo date('Y-m-d'); ?>" required>
				<!-- check out -->
				<input type="date" id="end_date" name="end_date" required>
				
				<button type="submit" name="number_of_adults" value="2"><?php echo $settings['jeff_searchavailability_content']; ?></button>
			</form>
			
		</div>
		
		<?php
		endif;  //end condition for empty form


		// form validation
		if(isset($_GET['formsubmit'])){

			// Get the start date and end date from the form
			$start_date   = $_GET['start_date'];
			$end_date     = $_GET['end_date'];
			$redirect_url = $settings['jeff_redirect_url']['url'];
		
			// Construct the redirect URL with the specified date parameters
			$redirect_url = $redirect_url . '?start_date=' . urlencode($start_date) . '&end_date=' . urlencode($end_date);
		
			// Redirect the user to the constructed URL
			header('Location: ' . $redirect_url);
		
			exit; // Make sure to exit after redirection to prevent further execution
		
		}



	} //end render

	// for live changes /////////////
	// protected function content_template() { 

		
			
		
	
	// }  // end content_template
}