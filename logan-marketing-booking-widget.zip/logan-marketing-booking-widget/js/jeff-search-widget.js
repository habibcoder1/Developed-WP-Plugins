(function($){
    'use strict';
    jQuery(document).ready(function($){

        // Script for Search Function //////////
        let startDateInput = document.getElementById('start_date');
        let endDateInput   = document.getElementById('end_date');

        // Get today's date
        let today = new Date();
        let todayFormatted = today.toISOString().split('T')[0];

        // Set the min attribute of start date to today's date
        startDateInput.setAttribute('min', todayFormatted);

        // Add event listener for change event on start date input
        startDateInput.addEventListener('change', function() {
            let selectedStartDate = new Date(startDateInput.value);
            let nextDay = new Date(selectedStartDate);
            nextDay.setDate(selectedStartDate.getDate() + 1); // Increment by one day

            // Set the value and min attribute of end date to the next day
            endDateInput.value = nextDay.toISOString().split('T')[0];
            endDateInput.setAttribute('min', nextDay.toISOString().split('T')[0]);
        });

        // Trigger change event on start date input to initialize end date
        startDateInput.dispatchEvent(new Event('change'));

        
    });
}(jQuery));
