<?php  
// Silence is golden
